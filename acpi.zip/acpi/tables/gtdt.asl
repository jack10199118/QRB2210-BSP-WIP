; GTDT for QRB2210. Arch timer PPIs from qcm2290.dtsi: DT PPI order 1,2,3,0 = INTID 17,18,19,16.
; Flags: 0x2 = level-triggered, active low. TODO(HW): set Always-On (bit 2) if the timer is in a
; power domain that stays on in deep idle. MMIO timer frames (0x0F120000) intentionally omitted.
[0004]                          Signature : "GTDT"
[0004]                       Table Length : 00000000
[0001]                           Revision : 02
[0001]                           Checksum : 00
[0006]                             Oem ID : "QCOM  "
[0008]                       Oem Table ID : "QRB2210 "
[0004]                       Oem Revision : 00000001
[0004]                    Asl Compiler ID : "INTL"
[0004]            Asl Compiler Revision : 20200925
[0008]            Counter Block Address : FFFFFFFFFFFFFFFF
[0004]                           Reserved : 00000000
[0004]            Secure EL1 Interrupt : 00000011
[0004]       EL1 Flags (decoded below) : 00000002
[0004]        Non-Secure EL1 Interrupt : 00000012
[0004]   NEL1 Flags (decoded below) : 00000002
[0004]             Virtual Timer Interrupt : 00000013
[0004]    VT Flags (decoded below) : 00000002
[0004]        Non-Secure EL2 Interrupt : 00000010
[0004]   NEL2 Flags (decoded below) : 00000002
[0008]       Counter Read Block Address : FFFFFFFFFFFFFFFF
[0004]              Platform Timer Count : 00000000
[0004]            Platform Timer Offset : 00000000
