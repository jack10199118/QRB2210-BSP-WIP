; DBG2 for QRB2210: UART4 (GENI debug UART) at 0x04A90000.
; TODO(HW): Port Subtype - Windows KD needs a KD extension matching the Qualcomm GENI UART;
; no standard subtype is assumed here. Offsets below are relative to the device info start.
[0004]                          Signature : "DBG2"
[0004]                       Table Length : 00000000
[0001]                           Revision : 00
[0001]                           Checksum : 00
[0006]                             Oem ID : "QCOM  "
[0008]                       Oem Table ID : "QRB2210 "
[0004]                       Oem Revision : 00000001
[0004]                    Asl Compiler ID : "INTL"
[0004]            Asl Compiler Revision : 20200925
[0004]                        Info Offset : 0000002C
[0004]                         Info Count : 00000001

[0001]                           Revision : 00
[0002]                             Length : 0031
[0001]                     Register Count : 01
[0002]                    Namepath Length : 000B
[0002]                    Namepath Offset : 0026
[0002]                    OEM Data Length : 0000
[0002]                    OEM Data Offset : 0000
[0002]                          Port Type : 8000        ; serial
[0002]                       Port Subtype : 0000        ; TODO(HW)
[0002]                           Reserved : 0000
[0002]                Base Address Offset : 0016
[0002]                Address Size Offset : 0022

[0001]                           Space ID : 00          ; system memory
[0001]                          Bit Width : 20
[0001]                         Bit Offset : 00
[0001]                       Access Width : 03
[0008]                            Address : 0000000004A90000

[0004]                       Address Size : 00004000
[000B]                          Namepath : "\_SB_.UAR4"
