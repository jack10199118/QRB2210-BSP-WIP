; MADT for QRB2210. Source: qcm2290.dtsi (CPU regs, GIC node, PMU PPI 6).
; Compile: iasl madt.asl
[0004]                          Signature : "APIC"
[0004]                       Table Length : 00000000
[0001]                           Revision : 05
[0001]                           Checksum : 00
[0006]                             Oem ID : "QCOM  "
[0008]                       Oem Table ID : "QRB2210 "
[0004]                       Oem Revision : 00000001
[0004]                    Asl Compiler ID : "INTL"
[0004]            Asl Compiler Revision : 20200925
[0004]                Local Apic Address : 00000000
[0004]              Flags (decoded below) : 00000000

[0001]                      Subtable Type : 0B [Generic Interrupt Controller]
[0001]                             Length : 50
[0002]                           Reserved : 0000
[0004]               CPU Interface Number : 00000000
[0004]                      Processor UID : 00000000
[0004]              Flags (decoded below) : 00000001
[0004]             Parking Protocol Version : 00000000
[0004]                 Performance Interrupt : 00000016   ; PMU: PPI 6 = INTID 22
[0008]                      Parked Address : 0000000000000000
[0008]                       Base Address : 0000000000000000   ; GICv3: use system registers
[0008]               Virtual GIC Base Address : 0000000000000000
[0008]            Hypervisor GIC Base Address : 0000000000000000
[0004]                Virtual GIC Interrupt : 00000019   ; GIC maintenance: PPI 9 = INTID 25
[0008]           Redistributor Base Address : 0000000000000000   ; use GICR range structure below
[0008]                         ARM MPIDR : 0000000000000000
[0001]                   Efficiency Class : 00
[0001]                           Reserved : 00
[0002]            SPE Overflow Interrupt : 0000

[0001]                      Subtable Type : 0B [Generic Interrupt Controller]
[0001]                             Length : 50
[0002]                           Reserved : 0000
[0004]               CPU Interface Number : 00000001
[0004]                      Processor UID : 00000001
[0004]              Flags (decoded below) : 00000001
[0004]             Parking Protocol Version : 00000000
[0004]                 Performance Interrupt : 00000016   ; PMU: PPI 6 = INTID 22
[0008]                      Parked Address : 0000000000000000
[0008]                       Base Address : 0000000000000000   ; GICv3: use system registers
[0008]               Virtual GIC Base Address : 0000000000000000
[0008]            Hypervisor GIC Base Address : 0000000000000000
[0004]                Virtual GIC Interrupt : 00000019   ; GIC maintenance: PPI 9 = INTID 25
[0008]           Redistributor Base Address : 0000000000000000   ; use GICR range structure below
[0008]                         ARM MPIDR : 0000000000000001
[0001]                   Efficiency Class : 00
[0001]                           Reserved : 00
[0002]            SPE Overflow Interrupt : 0000

[0001]                      Subtable Type : 0B [Generic Interrupt Controller]
[0001]                             Length : 50
[0002]                           Reserved : 0000
[0004]               CPU Interface Number : 00000002
[0004]                      Processor UID : 00000002
[0004]              Flags (decoded below) : 00000001
[0004]             Parking Protocol Version : 00000000
[0004]                 Performance Interrupt : 00000016   ; PMU: PPI 6 = INTID 22
[0008]                      Parked Address : 0000000000000000
[0008]                       Base Address : 0000000000000000   ; GICv3: use system registers
[0008]               Virtual GIC Base Address : 0000000000000000
[0008]            Hypervisor GIC Base Address : 0000000000000000
[0004]                Virtual GIC Interrupt : 00000019   ; GIC maintenance: PPI 9 = INTID 25
[0008]           Redistributor Base Address : 0000000000000000   ; use GICR range structure below
[0008]                         ARM MPIDR : 0000000000000002
[0001]                   Efficiency Class : 00
[0001]                           Reserved : 00
[0002]            SPE Overflow Interrupt : 0000

[0001]                      Subtable Type : 0B [Generic Interrupt Controller]
[0001]                             Length : 50
[0002]                           Reserved : 0000
[0004]               CPU Interface Number : 00000003
[0004]                      Processor UID : 00000003
[0004]              Flags (decoded below) : 00000001
[0004]             Parking Protocol Version : 00000000
[0004]                 Performance Interrupt : 00000016   ; PMU: PPI 6 = INTID 22
[0008]                      Parked Address : 0000000000000000
[0008]                       Base Address : 0000000000000000   ; GICv3: use system registers
[0008]               Virtual GIC Base Address : 0000000000000000
[0008]            Hypervisor GIC Base Address : 0000000000000000
[0004]                Virtual GIC Interrupt : 00000019   ; GIC maintenance: PPI 9 = INTID 25
[0008]           Redistributor Base Address : 0000000000000000   ; use GICR range structure below
[0008]                         ARM MPIDR : 0000000000000003
[0001]                   Efficiency Class : 00
[0001]                           Reserved : 00
[0002]            SPE Overflow Interrupt : 0000

[0001]                      Subtable Type : 0C [Generic Interrupt Distributor]
[0001]                             Length : 18
[0002]                           Reserved : 0000
[0004]                       Local GIC Id : 00000000
[0008]                       Base Address : 000000000F200000
[0004]                      Interrupt Base : 00000000
[0001]                         Version : 03
[0003]                           Reserved : 000000

[0001]                      Subtable Type : 0E [Generic Redistributor]
[0001]                             Length : 10
[0002]                           Reserved : 0000
[0008]                       Base Address : 000000000F300000
[0004]                             Length : 00100000
