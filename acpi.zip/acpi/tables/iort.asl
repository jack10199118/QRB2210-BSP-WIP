; IORT for QRB2210: SMMU-500 + named components SDC1/SDC2. GENERATED, not validated with iasl.
; Source: qcm2290.dtsi apps_smmu; SIDs: SDC1=0xC0, SDC2=0xA0.
; TODO(HW): flags (DVM / coherent walk), second global IRQ (DT lists only one), and whether
; Windows should use the SMMU for these masters. Offsets below are computed by the generator.
[0004]  Signature : "IORT"
[0004]  Table Length : 00000000
[0001]  Revision : 00
[0001]  Checksum : 00
[0006]  Oem ID : "QCOM  "
[0008]  Oem Table ID : "QRB2210 "
[0004]  Oem Revision : 00000001
[0004]  Asl Compiler ID : "INTL"
[0004]  Asl Compiler Revision : 20200925
[0004]  Node Count : 00000003
[0004]  Node Offset : 00000030
[0004]  Reserved : 00000000

; ---- SMMU-500 (type 3) at table offset 0x30, length 524 ----
[0001]  Type : 03
[0002]  Length : 020C
[0001]  Revision : 00
[0004]  Identifier : 00000000
[0004]  Mapping Count : 00000000
[0004]  Mapping Offset : 00000000
[0008]  Base Address : 000000000C600000
[0008]  Span : 0000000000080000
[0004]  Model : 00000003               ; ARM MMU-500
[0004]  Flags : 00000000               ; TODO(HW)
[0004]  Global Interrupt Array Offset : 0000003C
[0004]  Context Interrupt Count : 00000038
[0004]  Context Interrupt Array Offset : 0000004C
[0004]  PMU Interrupt Count : 00000000
[0004]  PMU Interrupt Array Offset : 00000000
[0004]  SMMU_NSgIrpt : 00000071
[0004]  SMMU_NSgIrpt Flags : 00000000
[0004]  SMMU_NSgCfgIrpt : 00000071     ; TODO(HW): DT has one global IRQ
[0004]  SMMU_NSgCfgIrpt Flags : 00000000
[0004]  Context GSIV : 00000077
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000078
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000079
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000007A
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000007B
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000007C
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000007D
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000007E
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000007F
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000080
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000081
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000082
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000083
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000084
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000085
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000086
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000087
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000088
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000089
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000008A
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000008B
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000008C
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000008D
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000008E
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000008F
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000090
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000091
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000092
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000093
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000094
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000095
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000096
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000097
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000098
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 00000099
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000009A
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000009B
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000009C
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000009D
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000009E
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 0000009F
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 000000A0
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 000000A1
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 000000A2
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 000000A3
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 000000A4
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 000000A5
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 000000A6
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 000000A7
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 000000A8
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 000000A9
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 000000AA
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 000000AB
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 000000AC
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 000000AD
[0004]  Context Flags : 00000000
[0004]  Context GSIV : 000000AE
[0004]  Context Flags : 00000000

; ---- Named component SDC1 (type 1) at table offset 0x23C ----
[0001]  Type : 01
[0002]  Length : 003C
[0001]  Revision : 00
[0004]  Identifier : 00000000
[0004]  Mapping Count : 00000001
[0004]  Mapping Offset : 00000028
[0004]  Node Flags : 00000000
[0004]  Cache Coherency : 00000000   ; TODO(HW): matches _CCA in DSDT
[0001]  Allocation Hints : 00
[0002]  Reserved : 0000
[0001]  Memory Flags : 00
[0001]  Memory Address Size Limit : 20   ; 32-bit DMA; TODO(HW): raise if the master is 36/40-bit
[000B]  Device Object Name : "\_SB_.SDC1"   ; 11 bytes incl. NUL; mapping starts right after (offset 0x28)
[0004]  Input Base : 00000000
[0004]  ID Count : 00000000          ; count minus one: one ID
[0004]  Output Base : 000000C0       ; stream ID
[0004]  Output Reference : 00000030   ; SMMU node offset
[0004]  Flags : 00000000

; ---- Named component SDC2 (type 1) at table offset 0x278 ----
[0001]  Type : 01
[0002]  Length : 003C
[0001]  Revision : 00
[0004]  Identifier : 00000000
[0004]  Mapping Count : 00000001
[0004]  Mapping Offset : 00000028
[0004]  Node Flags : 00000000
[0004]  Cache Coherency : 00000000   ; TODO(HW): matches _CCA in DSDT
[0001]  Allocation Hints : 00
[0002]  Reserved : 0000
[0001]  Memory Flags : 00
[0001]  Memory Address Size Limit : 20   ; 32-bit DMA; TODO(HW): raise if the master is 36/40-bit
[000B]  Device Object Name : "\_SB_.SDC2"   ; 11 bytes incl. NUL; mapping starts right after (offset 0x28)
[0004]  Input Base : 00000000
[0004]  ID Count : 00000000          ; count minus one: one ID
[0004]  Output Base : 000000A0       ; stream ID
[0004]  Output Reference : 00000030   ; SMMU node offset
[0004]  Flags : 00000000
