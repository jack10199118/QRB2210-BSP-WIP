/* User-mode bring-up tool for the QRB2210 eMMC driver (read-only).
 * Build (Developer Command Prompt):  cl emmctest.c cfgmgr32.lib
 * Run as Administrator:              emmctest.exe [lba] [count]
 * Not compiled in the authoring environment: build errors are possible. */
#include <windows.h>
#include <cfgmgr32.h>
#include <initguid.h>
#include <stdio.h>
#include <stdlib.h>
#include <winioctl.h>

/* keep in sync with drivers/emmc/emmc_ioctl.h */
DEFINE_GUID(GUID_DEVINTERFACE_QRB2210_EMMC,
    0x7c2e4b90, 0x1d3a, 0x4e6f, 0x8a, 0x55, 0x0b, 0x9e, 0x3c, 0x7d, 0x21, 0xf4);
typedef struct { ULONG SectorCount, BusWidth, Ready; } EMMC_INFO;
typedef struct { ULONG Lba, Count; } EMMC_READ_REQUEST;
#define IOCTL_EMMC_GET_INFO     CTL_CODE(FILE_DEVICE_UNKNOWN, 0x900, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_EMMC_READ_SECTORS CTL_CODE(FILE_DEVICE_UNKNOWN, 0x901, METHOD_BUFFERED, FILE_ANY_ACCESS)

int wmain(int argc, wchar_t **argv)
{
    ULONG len = 0, lba = 0, count = 1, got = 0, i;
    WCHAR *list = NULL; HANDLE h; EMMC_INFO info; EMMC_READ_REQUEST rq; unsigned char *buf;

    if (argc > 1) lba = (ULONG)wcstoul(argv[1], NULL, 0);
    if (argc > 2) count = (ULONG)wcstoul(argv[2], NULL, 0);
    if (count == 0 || count > 128) { fprintf(stderr, "count must be 1..128\n"); return 2; }

    if (CM_Get_Device_Interface_List_SizeW(&len, (LPGUID)&GUID_DEVINTERFACE_QRB2210_EMMC, NULL, 0) != CR_SUCCESS || len < 2) {
        fprintf(stderr, "eMMC device interface not found (driver not loaded?)\n"); return 1;
    }
    list = (WCHAR *)malloc(len * sizeof(WCHAR));
    if (!list || CM_Get_Device_Interface_ListW((LPGUID)&GUID_DEVINTERFACE_QRB2210_EMMC, NULL, list, len, 0) != CR_SUCCESS) return 1;

    h = CreateFileW(list, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
    if (h == INVALID_HANDLE_VALUE) { fprintf(stderr, "open failed: %lu (run as Administrator)\n", GetLastError()); return 1; }

    if (!DeviceIoControl(h, IOCTL_EMMC_GET_INFO, NULL, 0, &info, sizeof info, &got, NULL)) {
        fprintf(stderr, "GET_INFO failed: %lu\n", GetLastError()); return 1;
    }
    printf("ready=%lu sectors=%lu (%lu MiB) bus=%lu-bit\n", info.Ready, info.SectorCount, info.SectorCount / 2048, info.BusWidth);

    buf = (unsigned char *)malloc(count * 512);
    rq.Lba = lba; rq.Count = count;
    if (!buf || !DeviceIoControl(h, IOCTL_EMMC_READ_SECTORS, &rq, sizeof rq, buf, count * 512, &got, NULL)) {
        fprintf(stderr, "READ failed: %lu\n", GetLastError()); return 1;
    }
    for (i = 0; i < 64 && i < got; i++) printf("%02x%s", buf[i], (i % 16 == 15) ? "\n" : " ");
    if (lba == 0 && got >= 512) printf("LBA0 signature: %02x %02x (%s)\n", buf[510], buf[511],
                                       (buf[510] == 0x55 && buf[511] == 0xAA) ? "valid" : "NOT 55 AA");
    CloseHandle(h); free(buf); free(list);
    return 0;
}
