#!/usr/bin/env python3
"""Assemble the iasl-style data-table sources (madt/gtdt/dbg2/iort) into bytes and verify
their internal structure: lengths, offsets, references. This does NOT replace iasl; it only
catches self-consistency mistakes (wrong field widths, bad offsets). Run: python3 tools/check_tables.py"""
import re, struct, sys, pathlib

def assemble(path):
    out = bytearray(); fields = []   # (offset, width, name, value)
    for raw in pathlib.Path(path).read_text().splitlines():
        line = raw.split(';')[0].rstrip() if '"' not in raw.split(';')[0] else raw
        # keep ';' that sit inside quotes (none expected); strip comments otherwise
        line = re.sub(r'\s;.*$', '', raw).strip() if not raw.strip().startswith(';') else ''
        m = re.match(r'\[([0-9A-Fa-f]{4})\]\s+(.*?)\s*:\s*(.*)$', line)
        if not m: continue
        width = int(m.group(1), 16); name = m.group(2).strip(); val = m.group(3).strip()
        val = re.sub(r'\s*\[.*?\]\s*$', '', val).strip()           # drop "[description]" tags
        if val.startswith('"'):
            s = val.strip('"').encode() + b'\0'
            data = s[:width].ljust(width, b'\0')
        else:
            v = int(val.split()[0], 16)
            data = v.to_bytes(width, 'little')
        fields.append((len(out), width, name, data))
        out += data
    return out, fields

def u(b, o, n): return int.from_bytes(b[o:o+n], 'little')
errs = []
def chk(c, msg):
    if not c: errs.append(msg)

def finalize(b, name):
    b[4:8] = len(b).to_bytes(4, 'little')
    b[9] = 0; b[9] = (-sum(b)) & 0xFF
    return b

def check_madt(b):
    chk(b[0:4] == b'APIC', 'MADT signature')
    o = 44; n = 0
    while o < len(b):
        t, l = b[o], b[o+1]
        chk(l in (0x50, 0x18, 0x10), f'MADT subtable type {t:#x} unexpected length {l:#x}')
        o += l; n += 1
    chk(o == len(b), 'MADT subtables do not end exactly at table end')
    chk(n == 6, f'MADT expected 6 subtables (4 GICC + GICD + GICR), got {n}')

def check_gtdt(b):
    chk(b[0:4] == b'GTDT', 'GTDT signature'); chk(len(b) == 36 + 60, f'GTDT length {len(b)}')

def check_dbg2(b):
    chk(b[0:4] == b'DBG2', 'DBG2 signature')
    info = u(b, 36, 4); cnt = u(b, 40, 4); chk(info == 0x2C and cnt == 1, 'DBG2 info offset/count')
    d = info; ln = u(b, d+1, 2)
    chk(d + ln == len(b), f'DBG2 device length {ln} does not reach table end')
    nlen = u(b, d+4, 2); noff = u(b, d+6, 2); boff = u(b, d+18, 2); soff = u(b, d+20, 2)   # after rev,len,count,nlen,noff,olen,ooff,ptype,psub,rsvd
    chk(b[d+noff:d+noff+nlen-1] == b'\\_SB_.UAR4' and b[d+noff+nlen-1] == 0, 'DBG2 namepath at its offset')
    chk(u(b, d+boff+4, 8) == 0x04A90000, 'DBG2 base address at base-address offset')
    chk(u(b, d+soff, 4) == 0x4000, 'DBG2 address size at size offset')
    chk(boff + 12 == soff, 'DBG2 size follows generic address')

def check_iort(b):
    chk(b[0:4] == b'IORT', 'IORT signature')
    nn = u(b, 36, 4); no = u(b, 40, 4); chk(nn == 2 and no == 48, 'IORT node count/offset (SMMU + SDC1)')
    o = no; nodes = {}
    for i in range(nn):
        t, l = b[o], u(b, o+1, 2); nodes[o] = (t, l); o += l
    chk(o == len(b), f'IORT nodes end at {o}, table is {len(b)}')
    smmu = [k for k, v in nodes.items() if v[0] == 3]; chk(len(smmu) == 1, 'IORT one SMMU node')
    s = smmu[0]; sl = nodes[s][1]
    gref, cnum, cref = u(b, s+40, 4), u(b, s+44, 4), u(b, s+48, 4)   # after 16 B header, base, span, model, flags
    chk(gref == 0x3C, f'IORT global array offset {gref:#x}')
    chk(cref == gref + 16, 'IORT context array follows global array')
    chk(cref + cnum * 8 == sl, f'IORT SMMU node length {sl} vs computed {cref + cnum*8}')
    chk(u(b, s+16, 8) == 0x0C600000, 'IORT SMMU base')
    for k, (t, l) in nodes.items():
        if t != 1: continue
        mc, mo = u(b, k+8, 4), u(b, k+12, 4)
        chk(mc == 1 and mo + 20 == l, f'IORT named comp @{k:#x}: mapping offset {mo:#x} + 20 != length {l}')
        name = b[k+29:k+mo].rstrip(b'\0')
        chk(name.startswith(b'\\_SB_.SDC'), f'IORT named comp name {name!r}')
        outref = u(b, k+mo+12, 4); chk(outref == s, f'IORT mapping output reference {outref:#x} != SMMU node {s:#x}')
        chk(u(b, k+mo+4, 4) == 0, 'IORT ID count must be (count-1)=0 for one ID')
    sids = sorted(u(b, k+u(b, k+12, 4)+8, 4) for k, v in nodes.items() if v[0] == 1)
    chk(sids == [0xC0], f'IORT stream IDs {sids}')

base = pathlib.Path(__file__).resolve().parent.parent / 'acpi' / 'tables'
for name, fn in (('madt', check_madt), ('gtdt', check_gtdt), ('dbg2', check_dbg2), ('iort', check_iort)):
    b, _ = assemble(base / f'{name}.asl'); b = finalize(b, name); before = len(errs); fn(b)
    print(f'{name}: {len(b)} bytes, {"OK" if len(errs) == before else "PROBLEMS"}')
for e in errs: print('  -', e)
sys.exit(1 if errs else 0)
