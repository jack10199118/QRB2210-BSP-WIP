#!/bin/sh
set -e
cd "$(dirname "$0")"
OUT="${TMPDIR:-/tmp}"
gcc -std=c99 -Wall -Wextra -DEMMC_HOST_TEST -o "$OUT/emmc_host_test" host_test.c ../drivers/emmc/emmc_core.c
"$OUT/emmc_host_test"
gcc -std=gnu11 -Wall -Wextra -I stubs -I ../drivers/qcompwr -o "$OUT/policy_test" policy_test.c
"$OUT/policy_test"
python3 ../tools/check_tables.py
