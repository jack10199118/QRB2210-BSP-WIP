#!/bin/sh
set -e
cd "$(dirname "$0")"
OUT="${TMPDIR:-/tmp}"
gcc -std=c99 -Wall -Wextra -DEMMC_HOST_TEST -o "$OUT/emmc_host_test" host_test.c ../drivers/emmc/emmc_core.c
"$OUT/emmc_host_test"
gcc -std=c99 -Wall -Wextra -DQCOM_HOST_TEST -o "$OUT/res_test" res_test.c ../drivers/qcompwr/qcom_res.c
"$OUT/res_test"
gcc -std=c99 -Wall -Wextra -DTLMM_HOST_TEST -o "$OUT/tlmm_test" tlmm_test.c ../drivers/tlmm/tlmm_core.c
"$OUT/tlmm_test"
python3 ../tools/check_tables.py
