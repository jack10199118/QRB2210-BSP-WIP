#include <stdio.h>
#include <string.h>
#include "../drivers/tlmm/tlmm_core.h"

static unsigned char mem[127 * 0x1000 + 0x1000];
static struct { u32 off, val; } wlog[64]; static int nw;
static int ext_in[128];                        /* level driven externally on an input pin */

u32 tl_rd(u32 off)
{
    u32 v; memcpy(&v, &mem[off], 4);
    if ((off % 0x1000) == 4) {                 /* IO register: IN bit follows OUT when OE set, else external */
        u32 pin = off / 0x1000, ctl; memcpy(&ctl, &mem[pin * 0x1000], 4);
        v &= ~1u;
        if (ctl & (1u << 9)) v |= (v >> 1) & 1u; else v |= ext_in[pin] ? 1u : 0u;
    }
    return v;
}
void tl_wr(u32 off, u32 val) { memcpy(&mem[off], &val, 4); if (nw < 64) { wlog[nw].off = off; wlog[nw].val = val; nw++; } }

static int fails;
#define CHECK(c, m) do { if (!(c)) { printf("FAIL: %s\n", m); fails++; } else printf("ok:   %s\n", m); } while (0)
static u32 rd(u32 off) { u32 v; memcpy(&v, &mem[off], 4); return v; }

int main(void)
{
    TLMM t; int v = -1, r;
    tlmm_init(&t, mem, 127);
    tlmm_claim_rb1_board_pins(&t);

    CHECK(tlmm_config_input(&t, 96, TLMM_OWNER_NONE, TLMM_PULL_UP) == TLMM_OK && (rd(96 * 0x1000) & 3) == 3, "input with pull-up: pull bits set (pin 96)");
    ext_in[96] = 1;
    CHECK(tlmm_get(&t, 96, TLMM_OWNER_NONE, &v) == TLMM_OK && v == 1, "input level read back");
    ext_in[96] = 0;
    CHECK(tlmm_get(&t, 96, TLMM_OWNER_NONE, &v) == TLMM_OK && v == 0, "input level follows the pin");

    nw = 0;
    CHECK(tlmm_config_output(&t, 45, TLMM_OWNER_NONE, 1, 8) == TLMM_OK, "configure pin 45 as output, high, 8 mA");
    CHECK(nw == 2 && wlog[0].off == 45 * 0x1000 + 4 && wlog[1].off == 45 * 0x1000, "output level written BEFORE the driver is enabled (no glitch)");
    CHECK((rd(45 * 0x1000) & (1u << 9)) && ((rd(45 * 0x1000) >> 6) & 7) == 3, "OE set and drive field = (8/2)-1 = 3");
    CHECK(tlmm_set(&t, 45, TLMM_OWNER_NONE, 0) == TLMM_OK && !(rd(45 * 0x1000 + 4) & 2), "set output low");
    CHECK(tlmm_set(&t, 96, TLMM_OWNER_NONE, 1) == TLMM_E_ARG, "writing an input pin is refused");
    CHECK(tlmm_config_output(&t, 45, TLMM_OWNER_NONE, 0, 3) == TLMM_E_ARG, "odd drive strength refused");
    CHECK(tlmm_config_output(&t, 45, TLMM_OWNER_NONE, 0, 18) == TLMM_E_ARG, "drive strength above 16 mA refused");

    CHECK(tlmm_config_output(&t, 88, TLMM_OWNER_NONE, 1, 2) == TLMM_E_OWNED, "generic client cannot drive SD card-detect (88)");
    CHECK(tlmm_get(&t, 87, TLMM_OWNER_NONE, &v) == TLMM_E_OWNED, "generic client cannot touch Bluetooth enable (87)");
    CHECK(tlmm_config_output(&t, 87, TLMM_OWNER_BT_ENABLE, 1, 2) == TLMM_OK, "the owner can drive its pin");
    CHECK(tlmm_config_output(&t, 87, TLMM_OWNER_SDC2_CD, 1, 2) == TLMM_E_OWNED, "a different owner cannot drive it");
    CHECK(tlmm_claim(&t, 87, TLMM_OWNER_SDC2_CD) == TLMM_E_OWNED, "an owned pin cannot be re-claimed by another owner");
    CHECK(tlmm_release(&t, 87, TLMM_OWNER_SDC2_CD) == TLMM_E_OWNED, "only the owner can release");
    CHECK(tlmm_release(&t, 87, TLMM_OWNER_BT_ENABLE) == TLMM_OK && tlmm_get(&t, 87, TLMM_OWNER_NONE, &v) == TLMM_OK, "after release the pin is generic again");

    CHECK(tlmm_set_function(&t, 8, TLMM_OWNER_NONE, 3) == TLMM_OK && ((rd(8 * 0x1000) >> 2) & 0xF) == 3, "function select field programmed");
    CHECK(tlmm_set_function(&t, 8, TLMM_OWNER_NONE, 16) == TLMM_E_ARG, "function above 15 refused");
    CHECK(tlmm_config_input(&t, 127, TLMM_OWNER_NONE, TLMM_PULL_NONE) == TLMM_E_RANGE, "pin beyond 126 refused");
    CHECK(tlmm_claim(&t, 5, TLMM_OWNER_NONE) == TLMM_E_ARG, "claiming with the generic owner id refused");
    r = tlmm_get(&t, 200, TLMM_OWNER_NONE, &v);
    CHECK(r == TLMM_E_RANGE, "out-of-range pin on read refused");

    printf("%s (%d failure%s)\n", fails ? "TLMM TESTS FAILED" : "TLMM TESTS PASSED", fails, fails == 1 ? "" : "s");
    return fails != 0;
}
