/* Host-side test of emmc_core against a simulated SDHCI controller + eMMC card.
 * Build/run: sh run_tests.sh   (needs gcc). Verifies command sequencing, register
 * encodings and ADMA2 tables. It cannot prove behaviour on real Qualcomm silicon. */
#include <stdio.h>
#include <string.h>
#include "../drivers/emmc/emmc_core.h"

static u8  regs[0x100];
static u8  phys[0x40000];
static int cmd1_calls, no_response, last_switch_idx, last_switch_val, last_cmd, last_cmd_flags;
static u32 last_mode;
static int sim_cmd1_mode, sim_switch_err, after_reset_calls, set_rate_calls; static u32 set_rate_hz;

u32 sim_rd(u32 off, int bytes)
{
    u32 v = 0; int i;
    if (off == 0x24) return 0;                         /* never inhibited */
    for (i = 0; i < bytes; i++) v |= (u32)regs[off + i] << (8 * i);
    return v;
}

static u32 rd_phys32(u32 a) { u32 v; memcpy(&v, &phys[a], 4); return v; }

static void fill_via_adma(int lba_base, int is_extcsd)
{
    u32 table, i = 0, sector = 0;
    memcpy(&table, &regs[0x58], 4);                    /* ADMA table address register */
    for (;; i++) {
        u16 attr, len; u32 addr;
        memcpy(&attr, &phys[table + i * 8], 2); memcpy(&len, &phys[table + i * 8 + 2], 2);
        addr = rd_phys32(table + i * 8 + 4);
        if (is_extcsd) {
            memset(&phys[addr], 0, 512);
            phys[addr + 212] = 0x00; phys[addr + 213] = 0x70; phys[addr + 214] = 0x74; phys[addr + 215] = 0x00;
        } else {
            u32 n;
            for (n = 0; n < len; n++) phys[addr + n] = (u8)((lba_base + sector + n / 512) & 0xFF);
            if (lba_base == 0 && sector == 0 && len >= 512) { phys[addr + 510] = 0x55; phys[addr + 511] = 0xAA; }
            sector += len / 512;
        }
        if (attr & 2) break;
    }
}

static void run_cmd(u32 val)
{
    u32 idx = val >> 8, arg = sim_rd(0x08, 4), flags = val & 0xFF;
    u32 *intst = (u32 *)&regs[0x30];
    u32 *resp = (u32 *)&regs[0x10];
    last_cmd = (int)idx; last_cmd_flags = (int)flags; last_mode = sim_rd(0x0C, 2);
    if (no_response) { *intst |= (1u << 15) | (1u << 16); return; }
    memset(&regs[0x10], 0, 16);
    *intst |= 1;
    switch (idx) {
    case 1: cmd1_calls++;
        resp[0] = 0x00FF8080u | (sim_cmd1_mode == 2 ? 0 : 0x40000000u)
                | ((sim_cmd1_mode != 1 && cmd1_calls >= 3) ? 0x80000000u : 0);
        break;
    case 2: resp[0] = 0x11111111; resp[1] = 0x22222222; resp[2] = 0x33333333; resp[3] = 0x44444444; break;
    case 6: last_switch_idx = (arg >> 16) & 0xFF; last_switch_val = (arg >> 8) & 0xFF; resp[0] = sim_switch_err ? 0x80u : 0; *intst |= 2; break;
    case 7: *intst |= 2; break;
    case 8: fill_via_adma(0, 1); *intst |= 2; break;
    case 13: resp[0] = 0x900; break;
    case 17: case 18: fill_via_adma((int)arg, 0); *intst |= 2; break;
    case 24: case 25: *intst |= 2; break;                 /* write data accepted */
    default: break;
    }
}

void sim_wr(u32 off, int bytes, u32 val)
{
    int i;
    if (off == 0x30) { u32 *p = (u32 *)&regs[0x30]; *p &= ~val; return; }   /* write-1-to-clear */
    if (off == 0x2F) { regs[0x2F] = 0; return; }                              /* reset completes at once */
    if (off == 0x0E) { regs[0x0E] = (u8)val; regs[0x0F] = (u8)(val >> 8); run_cmd(val); return; }
    for (i = 0; i < bytes; i++) regs[off + i] = (u8)(val >> (8 * i));
    if (off == 0x2C && (val & 1)) regs[0x2C] |= 2;                            /* internal clock stable */
}

static void dly(void *ctx, u32 us) { (void)ctx; (void)us; }
static void after_reset(void *ctx) { (void)ctx; after_reset_calls++; }
static int set_rate(void *ctx, u32 hz) { (void)ctx; set_rate_calls++; set_rate_hz = hz; return 0; }
static void reset_model(EMMC_CORE *c)
{
    memset(regs, 0, sizeof regs); cmd1_calls = 0; no_response = 0; sim_cmd1_mode = 0; sim_switch_err = 0;
    after_reset_calls = 0; set_rate_calls = 0; set_rate_hz = 0; c->Rca = 0; c->SectorCount = 0; c->BusWidth = 0;
}
static int fails;
#define CHECK(cond, msg) do { if (!(cond)) { printf("FAIL: %s\n", msg); fails++; } else printf("ok:   %s\n", msg); } while (0)

int main(void)
{
    EMMC_CORE c; u32 used = 0, clkreg; int r;
    memset(&c, 0, sizeof c);
    c.Regs = regs; c.AdmaVa = &phys[0x1000]; c.AdmaLa = 0x1000; c.AdmaBytes = 4096;
    c.DelayUs = dly; c.BaseClockHz = 100000000u;

    /* ADMA2 table builder */
    CHECK(emmc_build_adma2(&phys[0x1000], 4096, 0x10000, 512, &used) == 0 && used == 1, "ADMA: 512 B -> 1 descriptor");
    CHECK((phys[0x1000] & 0x23) == 0x23, "ADMA: valid+end+tran attributes");
    CHECK(emmc_build_adma2(&phys[0x1000], 4096, 0x10000, 65536, &used) == 0 && used == 2, "ADMA: 64 KiB -> 2 descriptors");
    CHECK((phys[0x1000] & 2) == 0 && (phys[0x1008] & 2) == 2, "ADMA: only last descriptor has END");
    CHECK(emmc_build_adma2(&phys[0x1000], 4096, 0x10002, 512, &used) == EMMC_E_BADARG, "ADMA: unaligned address rejected");
    CHECK(emmc_build_adma2(&phys[0x1000], 4096, 0xFFFFFF00ULL, 512, &used) == EMMC_E_BADARG, "ADMA: address crossing 4 GiB rejected");

    /* clock divider encoding (no platform SetRate) */
    r = emmc_set_clock(&c, 400000);
    clkreg = sim_rd(0x2C, 2);
    CHECK(r == 0 && ((clkreg >> 8) & 0xFF) == 125 && (clkreg & 7) == 7, "clock: 100 MHz base -> 400 kHz uses divider 125, clock enabled");

    /* full card init */
    memset(regs, 0, sizeof regs);
    r = emmc_card_init(&c, 0x2000, &phys[0x2000]);
    CHECK(r == 0, "init: sequence completes");
    CHECK(cmd1_calls == 3, "init: CMD1 repeated until power-up bit");
    CHECK(c.SectorCount == 0x00747000u, "init: sector count read from EXT_CSD[212..215]");
    CHECK(c.BusWidth == 8 && (regs[0x28] & 0x20), "init: 8-bit bus selected in card and host");
    CHECK((regs[0x28] & 0x04), "init: host high-speed bit set");
    CHECK(last_switch_idx == 183 && last_switch_val == 2, "init: last SWITCH sets BUS_WIDTH=8-bit");
    CHECK(last_cmd == 13, "init: ends with CMD13 status check");

    /* read path */
    r = emmc_read(&c, 0, 1, 0x10000);
    CHECK(r == 0 && phys[0x10000 + 510] == 0x55 && phys[0x10000 + 511] == 0xAA, "read: LBA 0 returns boot signature");
    CHECK(last_cmd == 17 && (last_cmd_flags & 0x20), "read: single block uses CMD17 with data-present");
    r = emmc_read(&c, 8, 128, 0x10000);
    CHECK(r == 0 && last_cmd == 18 && (last_mode & 0x04) && (last_mode & 0x20) && (last_mode & 0x10),
          "read: multi-block uses CMD18, auto-CMD12, multi, read direction");
    CHECK(phys[0x10000] == 8 && phys[0x10000 + 512 * 127] == (u8)(8 + 127), "read: 64 KiB across two descriptors is contiguous");

    /* error path */
    no_response = 1;
    r = emmc_cmd(&c, 13, 0, RSP_R1);
    CHECK(r == EMMC_E_TIMEOUT, "error: command timeout reported");
    no_response = 0;

    /* more init/write/callback cases */
    reset_model(&c); c.AfterReset = after_reset;
    r = emmc_card_init(&c, 0x2000, &phys[0x2000]);
    CHECK(r == 0 && after_reset_calls == 1, "hook: AfterReset called exactly once during init");

    reset_model(&c); sim_cmd1_mode = 1;
    CHECK(emmc_card_init(&c, 0x2000, &phys[0x2000]) == EMMC_E_TIMEOUT && cmd1_calls == 200, "init: card never powering up -> timeout after 200 CMD1");

    reset_model(&c); sim_cmd1_mode = 2;
    CHECK(emmc_card_init(&c, 0x2000, &phys[0x2000]) == EMMC_E_CARD, "init: byte-addressed card rejected");

    reset_model(&c); sim_switch_err = 1;
    CHECK(emmc_card_init(&c, 0x2000, &phys[0x2000]) == EMMC_E_CARD, "init: SWITCH_ERROR in status -> EMMC_E_CARD");

    reset_model(&c); c.SetRate = set_rate;
    r = emmc_card_init(&c, 0x2000, &phys[0x2000]);
    CHECK(r == 0 && set_rate_calls == 2 && set_rate_hz == 52000000u, "clock: platform SetRate used for 400 kHz then 52 MHz");
    CHECK(((sim_rd(0x2C, 2) >> 8) & 0xFF) == 0, "clock: SDHCI divider left at 0 when platform sets the core clock");
    c.SetRate = NULL; c.AfterReset = NULL;

    CHECK(emmc_write(&c, 100, 1, 0x10000) == 0 && last_cmd == 24 && !(last_mode & 0x10), "write: single block uses CMD24, write direction");
    CHECK(emmc_write(&c, 100, 8, 0x10000) == 0 && last_cmd == 25 && (last_mode & 0x04) && !(last_mode & 0x10), "write: multi-block uses CMD25 with auto-CMD12");
    CHECK(emmc_read(&c, 0, 0, 0x10000) == EMMC_E_BADARG, "read: zero blocks rejected");
    CHECK(emmc_read(&c, 0, 70000, 0x10000) == EMMC_E_BADARG, "read: >65535 blocks rejected");
    CHECK(emmc_set_power(&c, 2500) == EMMC_E_BADARG, "power: unsupported voltage rejected");

    printf("%s (%d failure%s)\n", fails ? "TESTS FAILED" : "ALL TESTS PASSED", fails, fails == 1 ? "" : "s");
    return fails != 0;
}
