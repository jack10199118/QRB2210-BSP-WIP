/* Host test of the board safety policy in qcom_pwr_policy.h */
#include <stdio.h>
#include "../drivers/qcompwr/qcom_pwr_policy.h"
static int fails;
#define CHECK(c, m) do { if (!(c)) { printf("FAIL: %s\n", m); fails++; } else printf("ok:   %s\n", m); } while (0)
int main(void)
{
    CHECK(QcomRegulatorPolicy(QCOM_REG_PM4125_L14, 0, 0) == QCOM_POLICY_DENIED, "L14 (SDC1 VQMMC) can never be turned off");
    CHECK(QcomRegulatorPolicy(QCOM_REG_PM4125_L14, 1, 1800000) == QCOM_POLICY_OK, "L14 on at 1.8 V allowed");
    CHECK(QcomRegulatorPolicy(QCOM_REG_PM4125_L14, 1, 2500000) == QCOM_POLICY_INVALID, "L14 is fixed 1.8 V: other voltages refused");
    CHECK(QcomRegulatorPolicy(QCOM_REG_PM4125_L20, 1, 2950000) == QCOM_POLICY_OK, "L20 (VMMC) 2.95 V allowed");
    CHECK(QcomRegulatorPolicy(QCOM_REG_PM4125_L20, 0, 0) == QCOM_POLICY_OK, "L20 may be turned off");
    CHECK(QcomRegulatorPolicy(QCOM_REG_PM4125_L20, 1, 5000000) == QCOM_POLICY_INVALID, "L20 above DT maximum refused");
    CHECK(QcomRegulatorPolicy(QCOM_REG_PM4125_L20, 1, 1800000) == QCOM_POLICY_INVALID, "L20 below DT minimum refused");
    CHECK(QcomRegulatorPolicy(QCOM_REG_PM4125_L4, 1, 2700000) == QCOM_POLICY_OK, "L4 at its 2.7 V cap allowed");
    CHECK(QcomRegulatorPolicy(QCOM_REG_PM4125_L4, 1, 3000000) == QCOM_POLICY_INVALID, "L4 3.0 V refused (3 V signalling disabled)");
    CHECK(QcomRegulatorPolicy(QCOM_REG_COUNT, 1, 1800000) == QCOM_POLICY_INVALID, "unknown regulator id refused");
    CHECK(QcomClockPolicy(QCOM_CLK_SDC1_APPS, 1, 100000000) == QCOM_POLICY_OK, "clock 100 MHz allowed");
    CHECK(QcomClockPolicy(QCOM_CLK_SDC1_APPS, 1, 500000000) == QCOM_POLICY_INVALID, "clock above 384 MHz refused");
    CHECK(QcomClockPolicy(QCOM_CLK_COUNT, 1, 1) == QCOM_POLICY_INVALID, "unknown clock id refused");
    printf("%s (%d failure%s)\n", fails ? "POLICY TESTS FAILED" : "POLICY TESTS PASSED", fails, fails == 1 ? "" : "s");
    return fails != 0;
}
