# Platform compatibility layer: Windows ARM64 on QRB2210

Goal: make the QRB2210 look like hardware Windows already knows how to drive, with the
smallest amount of custom, vendor-specific code, all of it isolated in one place.

## 1. Layers

```
 Windows inbox stack   partmgr / disk / NTFS | SerCx2 | GpioClx / SpbCx | usbxhci | BasicDisplay
 ---------------------------------------------------------------------------------------------
 L3 Block drivers      eMMC SDPORT miniport | GENI UART | TLMM GPIO | GENI I2C/SPI | DWC3 glue
 ---------------------------------------------------------------------------------------------
 L2 Resource service   clocks | resets | regulators | pin ownership | bus/power-domain votes
 ---------------------------------------------------------------------------------------------
 L1 Platform description   ACPI: DSDT, MADT, GTDT, DBG2, IORT, FADT (+ _DSD resource names)
 ---------------------------------------------------------------------------------------------
 L0 Firmware           Qualcomm boot chain, UEFI, PSCI (vendor / NDA)
```

Rule: **everything chip-specific and NDA-bound lives in L2's backend.** L3 drivers only
talk to L2 through a small public interface, so they can be swapped or reused.

## 2. What exists in this repo

| Layer | Item | State |
|---|---|---|
| L1 | `acpi/` DSDT + MADT/GTDT/DBG2/IORT (validated structurally), FADT source | not yet through iasl |
| L2 | `drivers/qcompwr`: name-based registry (`qcom_res.c`), per-handle ownership, ref-counting, clock-rate arbitration, always-on rails, auto-release on handle close (host-tested) | hardware backend stubbed; table compiled in, not yet from ACPI `_DSD` |
| L3 | `emmc_core` (tested vs simulation) + KMDF bring-up shell + read-only IOCTLs | no SDPORT shell, no HS200 |
| L3 | `drivers/tlmm` GPIO core with pin ownership (recalled register layout, host-tested) | no GpioClx shell, no GPIO interrupts |
| L3 | `emmc_core` also: boot/RPMB/GP partition select, boot-size read | tested vs simulation |
| L3 | UART, I2C/SPI, USB | not started |

## 3. L2 resource service: design decisions

1. **Name-based, not ID-based (done; `_DSD` loading still to do).** Clients ask for resources by name (`sdc1_apps`, `sdc1_vmmc`).
   ACPI `_DSD` maps names to board-specific IDs and limits. Board differences (RB1 vs
   another board) then live in ACPI, not in driver code. Today the IDs are compiled in;
   move them to `_DSD` before adding a second board.
2. **Handle + ownership (done).** Each client opens the service and holds resources through its file
   object. On cleanup/close (including a crashed client) the service releases that client's
   votes. Implemented with one client slot per file object; 7 slots plus the service itself.
3. **Policy in one place (done).** Board rules (L14 never off, L4 capped) are enforced in the
   service, and are unit-tested. Keep it that way for every new rail.
4. **Reference counting for shared resources (done).** Two blocks sharing a clock or power domain
   must not turn it off under each other (XO, VDDCX corner votes).
5. **Replaceable by a PEP.** Windows' Platform Extension Plugin is the standard way for an
   SoC vendor to handle clocks and rails through the power framework, but I have not
   seen public documentation for writing one. Design the client interface so the service
   can later be replaced by a PEP without touching L3 drivers.
6. **Sequencing is the client's, safety is the service's.** The eMMC driver decides *when*
   (rails, then clocks, then reset); the service decides *whether* (limits, never-off rules).

## 4. L3 driver strategy

| Block | Windows class framework | Notes |
|---|---|---|
| eMMC (SDC1) | SDPORT miniport (`sdport.sys`) | split core already done; needs `sdport.h`; boot-start |
| SD slot (SDC2) | same miniport, card detect GPIO 88 | needs TLMM driver for CD |
| UART4 (debug) | SerCx2 or KD extension | KD over this UART needs a Qualcomm transport |
| TLMM GPIO | GpioClx | 127 pins (`gpio-ranges 0 0 127`); the supplied DTS declares no reserved ranges, but pins owned by other functions (e.g. SD card-detect GPIO 88, Bluetooth enable GPIO 87) should be refused to GPIO clients |
| I2C / SPI (GENI) | SpbCx | shared GENI engine firmware load may be needed |
| USB (DWC3) | inbox xHCI + glue | needs PHY/power and role-switch handling |
| Display | Basic Display via UEFI framebuffer | no Adreno driver available |

## 5. Boot and hand-off

- To boot from eMMC, UEFI loads the OS loader from it; Windows must then bring storage up
  early. The miniport and the resource service must be **boot-start** and in the boot
  critical device database.
- UEFI will have left SDC1 clocked and powered. Decide: reset the controller (simplest,
  assumed here) or adopt the running state. Resetting is safe only if no one else uses it.
- `_DEP` in the DSDT already orders the service before the eMMC. Boot-start ordering
  must be tested, not assumed.

## 6. Test strategy (what makes this safe to iterate)

- Pure logic (core, policy, table structure) is unit-tested on a host PC; keep new logic in
  OS-free C so it can be tested the same way.
- Every driver keeps a read-only debug interface; no debug write paths on boot media.
- Each milestone below has an observable exit criterion in the debugger.

## 7. Milestones

| # | Milestone | Exit criterion |
|---|---|---|
| M0 | Decisions: target OS image/arch; Qualcomm boot chain; vendor docs | answers in writing |
| M1 | UEFI + serial; ACPI tables compile and load | `iasl` clean; Windows boots to debugger |
| M2 | Resource service backend (GCC clocks, resets, RPM rails) | clock/rail measured on scope |
| M3 | eMMC bring-up shell | `card ready` and `55 aa` from LBA0 |
| M4 | SDPORT miniport | disk appears in Disk Management; read/write test |
| M5 | GPIO, UART, I2C/SPI | each block passes a loopback/probe |
| M6 | USB host, display | device enumerates; framebuffer visible |
| M7 | Hardening | power-down/up cycles, error injection, boot-start ordering |

## 8. Open decisions that block later work

1. Target OS image and architecture (ARM64 assumed throughout).
2. PEP vs custom resource service (custom assumed for bring-up).
3. Whether Windows owns the SMMU (IORT written assuming yes) or UEFI leaves it bypassed.
4. Reset vs adopt UEFI's hardware state for each block at hand-off.
5. Which Qualcomm components (firmware, drivers, KD transport) you can obtain under NDA.

## 9. Behaviour worth knowing (as implemented and tested)

- Shared clocks run at the highest rate any holder requests; when the fastest holder releases, the rate drops.
- Two holders of one rail must ask for the same voltage; otherwise the second gets `BUSY` and nothing changes.
- A failed enable leaves no hold; a failed disable keeps the hold (the rail is still on).
- Always-on rails (L14) are held by the service itself, so no client release can switch them off.
- **Bring-up mode:** if the backend returns "not implemented" while the service starts, always-on rails are
  *assumed on* (the firmware left them powered) and the count is logged. All later requests report
  `NOT_IMPLEMENTED` rather than faking success.
- Unknown: whether a resource's `_DSD` data should be able to *relax* these limits. Today it cannot.
