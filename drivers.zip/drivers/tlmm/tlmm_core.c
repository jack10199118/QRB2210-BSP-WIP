#include "tlmm_core.h"

#ifdef TLMM_HOST_TEST
extern u32  tl_rd(u32 off);
extern void tl_wr(u32 off, u32 val);
#define RD(T,o)    tl_rd((o))
#define WR(T,o,v)  tl_wr((o), (v))
#else
#define RD(T,o)    READ_REGISTER_ULONG((PULONG)((T)->Base + (o)))
#define WR(T,o,v)  WRITE_REGISTER_ULONG((PULONG)((T)->Base + (o)), (v))
#endif

#define CTL_PULL_MASK   0x3u
#define CTL_FUNC_SHIFT  2
#define CTL_FUNC_MASK   (0xFu << CTL_FUNC_SHIFT)
#define CTL_DRV_SHIFT   6
#define CTL_DRV_MASK    (0x7u << CTL_DRV_SHIFT)
#define CTL_OE          (1u << 9)
#define IO_IN           (1u << 0)
#define IO_OUT          (1u << 1)

static u32 ctl(u32 pin) { return pin * TLMM_PIN_STRIDE + TLMM_CTL; }
static u32 io(u32 pin)  { return pin * TLMM_PIN_STRIDE + TLMM_IO; }

void tlmm_init(TLMM *T, volatile unsigned char *Base, u32 PinCount)
{
    u32 i;
    T->Base = Base;
    T->PinCount = PinCount > TLMM_MAX_PINS ? TLMM_MAX_PINS : PinCount;
    for (i = 0; i < TLMM_MAX_PINS; i++) T->Owner[i] = TLMM_OWNER_NONE;
}

static int check(const TLMM *T, u32 Pin, u32 Owner)
{
    if (Pin >= T->PinCount) return TLMM_E_RANGE;
    if (T->Owner[Pin] != Owner) return TLMM_E_OWNED;      /* claimed by someone else, or not by you */
    return TLMM_OK;
}

int tlmm_claim(TLMM *T, u32 Pin, u32 Owner)
{
    if (Pin >= T->PinCount) return TLMM_E_RANGE;
    if (Owner == TLMM_OWNER_NONE) return TLMM_E_ARG;
    if (T->Owner[Pin] != TLMM_OWNER_NONE && T->Owner[Pin] != Owner) return TLMM_E_OWNED;
    T->Owner[Pin] = Owner;
    return TLMM_OK;
}

int tlmm_release(TLMM *T, u32 Pin, u32 Owner)
{
    if (Pin >= T->PinCount) return TLMM_E_RANGE;
    if (Owner == TLMM_OWNER_NONE || T->Owner[Pin] != Owner) return TLMM_E_OWNED;
    T->Owner[Pin] = TLMM_OWNER_NONE;
    return TLMM_OK;
}

int tlmm_set_function(TLMM *T, u32 Pin, u32 Owner, u32 Function)
{
    int r = check(T, Pin, Owner); u32 v;
    if (r) return r;
    if (Function > 0xF) return TLMM_E_ARG;
    v = RD(T, ctl(Pin));
    v = (v & ~CTL_FUNC_MASK) | (Function << CTL_FUNC_SHIFT);
    WR(T, ctl(Pin), v);
    return TLMM_OK;
}

int tlmm_config_input(TLMM *T, u32 Pin, u32 Owner, TLMM_PULL Pull)
{
    int r = check(T, Pin, Owner); u32 v;
    if (r) return r;
    v = RD(T, ctl(Pin));
    v &= ~(CTL_OE | CTL_PULL_MASK | CTL_FUNC_MASK);          /* function 0 = GPIO, output off */
    v |= (u32)Pull & CTL_PULL_MASK;
    WR(T, ctl(Pin), v);
    return TLMM_OK;
}

int tlmm_config_output(TLMM *T, u32 Pin, u32 Owner, int Value, u32 DriveMa)
{
    int r = check(T, Pin, Owner); u32 v;
    if (r) return r;
    if (DriveMa < 2 || DriveMa > 16 || (DriveMa & 1)) return TLMM_E_ARG;
    WR(T, io(Pin), Value ? IO_OUT : 0);                      /* set the level BEFORE enabling the driver: no glitch */
    v = RD(T, ctl(Pin));
    v &= ~(CTL_FUNC_MASK | CTL_DRV_MASK);
    v |= ((DriveMa / 2 - 1) << CTL_DRV_SHIFT) | CTL_OE;
    WR(T, ctl(Pin), v);
    return TLMM_OK;
}

int tlmm_get(TLMM *T, u32 Pin, u32 Owner, int *Value)
{
    int r = check(T, Pin, Owner);
    if (r) return r;
    *Value = (RD(T, io(Pin)) & IO_IN) ? 1 : 0;
    return TLMM_OK;
}

int tlmm_set(TLMM *T, u32 Pin, u32 Owner, int Value)
{
    int r = check(T, Pin, Owner);
    if (r) return r;
    if (!(RD(T, ctl(Pin)) & CTL_OE)) return TLMM_E_ARG;      /* pin is not an output */
    WR(T, io(Pin), Value ? IO_OUT : 0);
    return TLMM_OK;
}

void tlmm_claim_rb1_board_pins(TLMM *T)
{
    (void)tlmm_claim(T, 88, TLMM_OWNER_SDC2_CD);             /* SD card detect */
    (void)tlmm_claim(T, 87, TLMM_OWNER_BT_ENABLE);           /* WCN3950 Bluetooth enable */
}
