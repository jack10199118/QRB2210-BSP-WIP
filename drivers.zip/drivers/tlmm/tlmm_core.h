/*
 * QCM2290 TLMM (pin mux / GPIO) core. OS-free, host-testable (-DTLMM_HOST_TEST).
 * Register layout RECALLED from Linux drivers/pinctrl/qcom/pinctrl-msm.c (verify before use):
 *   per pin: base + 0x1000 * pin;  CTL @ +0x0, IO @ +0x4
 *   CTL: [1:0] pull (0 none, 1 down, 2 keeper, 3 up), [5:2] function, [8:6] drive ((mA/2)-1), [9] output enable
 *   IO:  bit0 = input level, bit1 = output level
 * Interrupt configuration is NOT implemented here.
 */
#ifndef TLMM_CORE_H
#define TLMM_CORE_H
#ifdef TLMM_HOST_TEST
#include <stdint.h>
typedef uint32_t u32;
#else
#include <ntddk.h>
typedef ULONG u32;
#endif

#define TLMM_PIN_STRIDE   0x1000u
#define TLMM_CTL          0x0u
#define TLMM_IO           0x4u
#define TLMM_MAX_PINS     128u

#define TLMM_OWNER_NONE   0u          /* generic GPIO clients */
enum { TLMM_OK = 0, TLMM_E_RANGE = -1, TLMM_E_OWNED = -2, TLMM_E_ARG = -3 };
typedef enum { TLMM_PULL_NONE = 0, TLMM_PULL_DOWN = 1, TLMM_PULL_KEEPER = 2, TLMM_PULL_UP = 3 } TLMM_PULL;

typedef struct _TLMM {
    volatile unsigned char *Base;
    u32 PinCount;
    u32 Owner[TLMM_MAX_PINS];   /* 0 = free for generic use */
} TLMM;

void tlmm_init(TLMM *T, volatile unsigned char *Base, u32 PinCount);
int  tlmm_claim(TLMM *T, u32 Pin, u32 Owner);               /* Owner != 0 */
int  tlmm_release(TLMM *T, u32 Pin, u32 Owner);
int  tlmm_set_function(TLMM *T, u32 Pin, u32 Owner, u32 Function);        /* 0 = GPIO */
int  tlmm_config_input(TLMM *T, u32 Pin, u32 Owner, TLMM_PULL Pull);
int  tlmm_config_output(TLMM *T, u32 Pin, u32 Owner, int Value, u32 DriveMa);
int  tlmm_get(TLMM *T, u32 Pin, u32 Owner, int *Value);
int  tlmm_set(TLMM *T, u32 Pin, u32 Owner, int Value);

/* Board pins owned by a fixed function on the RB1 (qrb2210-rb1.dts): generic clients must not drive them. */
enum { TLMM_OWNER_SDC2_CD = 1, TLMM_OWNER_BT_ENABLE = 2 };
void tlmm_claim_rb1_board_pins(TLMM *T);
#endif
