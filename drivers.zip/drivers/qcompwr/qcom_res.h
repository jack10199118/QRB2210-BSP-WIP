/*
 * Resource registry for the QRB2210 platform service. OS-free so it can be unit-tested on a host PC
 * (-DQCOM_HOST_TEST). Provides: lookup by NAME, per-client ownership, reference counting,
 * rate arbitration for shared clocks, voltage-conflict detection for shared rails, "always on" rails,
 * and automatic release when a client goes away.
 */
#ifndef QCOM_RES_H
#define QCOM_RES_H

#ifdef QCOM_HOST_TEST
#include <stdint.h>
typedef uint32_t u32; typedef uint8_t u8;
#else
#include <ntddk.h>
typedef ULONG u32; typedef UCHAR u8;
#endif

#define RES_MAX          16
#define RES_MAX_CLIENTS  8     /* slot 0 is the service itself (always-on holds) */

enum { RES_OK = 0, RES_E_NOENT = -1, RES_E_RANGE = -2, RES_E_BUSY = -3, RES_E_HW = -4,
       RES_E_NOTHELD = -5, RES_E_NOCLIENT = -6, RES_E_TYPE = -7, RES_E_NOTIMPL = -8 };

typedef enum { RES_CLOCK = 0, RES_RESET = 1, RES_REGULATOR = 2 } RES_TYPE;

typedef struct _RES_DESC {
    const char *Name;
    RES_TYPE    Type;
    u32         HwId;           /* backend-specific identifier */
    u32         MinVal, MaxVal; /* clock Hz / regulator uV; both 0 = value ignored */
    u8          AlwaysOn;       /* service holds it on forever (board rule) */
} RES_DESC;

/* Backend: return RES_OK, RES_E_NOTIMPL (not written yet) or RES_E_HW. */
typedef struct _RES_BACKEND {
    int (*Clock)(void *Ctx, u32 Hw, u32 Enable, u32 Hz);
    int (*Reset)(void *Ctx, u32 Hw);
    int (*Regulator)(void *Ctx, u32 Hw, u32 Enable, u32 Uv);
    void *Ctx;
} RES_BACKEND;

typedef struct _RES_STATE {
    u32 Count;                          /* number of holders */
    u32 Value;                          /* value currently programmed */
    u8  Held[RES_MAX_CLIENTS];
    u32 Req[RES_MAX_CLIENTS];           /* each holder's requested value */
} RES_STATE;

typedef struct _RES_REGISTRY {
    const RES_DESC *Desc;
    u32             NumDesc;
    RES_STATE       St[RES_MAX];
    u8              ClientOpen[RES_MAX_CLIENTS];
    RES_BACKEND     Be;
    u32             Adopted;            /* always-on rails assumed on because the backend is not implemented */
} RES_REGISTRY;

int  res_init(RES_REGISTRY *R, const RES_DESC *Desc, u32 Num, const RES_BACKEND *Be);
int  res_lookup(const RES_REGISTRY *R, const char *Name);          /* index or RES_E_NOENT */
int  res_client_open(RES_REGISTRY *R);                              /* client id 1.. or RES_E_NOCLIENT */
int  res_client_close(RES_REGISTRY *R, int Client);                 /* releases everything it holds */
int  res_acquire(RES_REGISTRY *R, int Client, int Idx, u32 Value);  /* enable, or change value if already held */
int  res_release(RES_REGISTRY *R, int Client, int Idx);
int  res_reset(RES_REGISTRY *R, int Client, int Idx);

#endif
