/* Board selection for the resource table. Default target: Arduino UNO Q ("imola").
 * Build with -DQCOM_BOARD_RB1 for the Qualcomm RB1 table instead. */
#ifndef QCOM_RES_TABLE_H
#define QCOM_RES_TABLE_H
#include "qcom_res.h"

/* backend hardware identifiers (service-internal; clients only use names) */
enum { QHW_CLK_XO = 0, QHW_CLK_SDC1_AHB, QHW_CLK_SDC1_APPS, QHW_CLK_SDC1_ICE_CORE, QHW_CLK_SDC2_AHB, QHW_CLK_SDC2_APPS };
enum { QHW_RST_SDC1_BCR = 0, QHW_RST_SDC2_BCR };
enum { QHW_REG_PM4125_L20 = 0, QHW_REG_PM4125_L14, QHW_REG_PM4125_L21, QHW_REG_PM4125_L4,
       QHW_REG_PM4125_L2, QHW_REG_PM4125_L3, QHW_REG_PM4125_L6, QHW_REG_PM4125_L11, QHW_REG_PM4125_L15,
       QHW_REG_PM4125_S3, QHW_REG_PM4125_S4 };

#if defined(QCOM_BOARD_RB1)
#include "qcom_res_table_rb1.h"
#else
#include "qcom_res_table_unoq.h"
#endif
#endif
