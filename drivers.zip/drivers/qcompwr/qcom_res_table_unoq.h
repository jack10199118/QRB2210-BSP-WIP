/* Arduino UNO Q ("imola", QRB2210). Source: upstream qrb2210-arduino-imola.dts (Linux patch series v3,
 * Nov 2025) + agatti/qcm2290 SoC dtsi. The final upstream file may differ in details: re-check it.
 *
 * Differences from the RB1 that matter here:
 *   - NO SD slot (sdhc_2 not enabled). L21 supplies USB HS, L4 is unused. No sdc2_* resources.
 *   - eMMC (SDC1): VMMC = L20 (2.4-3.6 V), VQMMC = L14 (1.8 V, "never turn it off").
 *   - Several rails feed DRAM or other always-on loads and must never be switched off.
 */
#ifndef QCOM_RES_TABLE_UNOQ_H
#define QCOM_RES_TABLE_UNOQ_H

static const RES_DESC g_BoardResources[] = {
    { "xo",            RES_CLOCK,     QHW_CLK_XO,            0,       0,          0 },
    { "sdc1_ahb",      RES_CLOCK,     QHW_CLK_SDC1_AHB,      0,       0,          0 },
    { "sdc1_apps",     RES_CLOCK,     QHW_CLK_SDC1_APPS,     100000,  384000000u, 0 },
    { "sdc1_ice_core", RES_CLOCK,     QHW_CLK_SDC1_ICE_CORE, 0,       0,          0 },
    { "sdc1_bcr",      RES_RESET,     QHW_RST_SDC1_BCR,      0,       0,          0 },
    { "sdc1_vmmc",     RES_REGULATOR, QHW_REG_PM4125_L20,    2400000, 3600000,    0 },
    { "sdc1_vqmmc",    RES_REGULATOR, QHW_REG_PM4125_L14,    1800000, 1800000,    1 },  /* "never turn it off" */
    /* always-on rails: held by the service forever so no client can ever switch them off */
    { "ddr_vdd2",      RES_REGULATOR, QHW_REG_PM4125_L2,     1136000, 1136000,    1 },  /* LPDDR4X VDD2 */
    { "ddr_vddq",      RES_REGULATOR, QHW_REG_PM4125_L3,     616000,  616000,     1 },  /* LPDDR4X VDDQ */
    { "ddr_pll",       RES_REGULATOR, QHW_REG_PM4125_L6,     928000,  928000,     1 },  /* DRAM PLL */
    { "anx_1v0",       RES_REGULATOR, QHW_REG_PM4125_L11,    1000000, 1000000,    1 },  /* ANX7625 DVDD/AVDD 1.0 V */
    { "vddio_1v8",     RES_REGULATOR, QHW_REG_PM4125_L15,    1800000, 1800000,    1 },  /* VDDIO */
    { "vdd_s3",        RES_REGULATOR, QHW_REG_PM4125_S3,     1352000, 1352000,    1 },  /* parent of L1-L3, L5-L12: treat as always-on */
    { "vdd_s4",        RES_REGULATOR, QHW_REG_PM4125_S4,     2072000, 2072000,    1 },  /* parent of L13-L16 */
};
#define BOARD_RES_COUNT (sizeof(g_BoardResources) / sizeof(g_BoardResources[0]))
#define BOARD_ALWAYS_ON_COUNT 8u
#endif
