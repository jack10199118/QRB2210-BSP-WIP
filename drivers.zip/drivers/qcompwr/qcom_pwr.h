/* Public interface of the QRB2210 platform resource service.
 * Clients open the device interface, then acquire/release resources BY NAME. Everything a client
 * holds is released automatically when its handle closes (including a crash). */
#pragma once
#include <ntddk.h>
#include <initguid.h>

/* {5A3C1E2B-7D44-4F0A-9B6E-2C8D1F0A4B77} */
DEFINE_GUID(GUID_DEVINTERFACE_QCOM_PWR,
    0x5a3c1e2b, 0x7d44, 0x4f0a, 0x9b, 0x6e, 0x2c, 0x8d, 0x1f, 0x0a, 0x4b, 0x77);

#define QCOM_RES_NAME_MAX 32

typedef struct _QCOM_RES_REQUEST {
    char  Name[QCOM_RES_NAME_MAX];   /* NUL-terminated resource name */
    ULONG Value;                     /* clock: Hz; regulator: microvolts; ignored otherwise */
} QCOM_RES_REQUEST, *PQCOM_RES_REQUEST;

#define IOCTL_QCOM_RES_ACQUIRE CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_QCOM_RES_RELEASE CTL_CODE(FILE_DEVICE_UNKNOWN, 0x801, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_QCOM_RES_RESET   CTL_CODE(FILE_DEVICE_UNKNOWN, 0x802, METHOD_BUFFERED, FILE_ANY_ACCESS)

/* Resource names for the RB1 board (see qcom_res_table.h) */
#define QRES_XO            "xo"
#define QRES_SDC1_AHB      "sdc1_ahb"
#define QRES_SDC1_APPS     "sdc1_apps"
#define QRES_SDC1_BCR      "sdc1_bcr"
#define QRES_SDC1_VMMC     "sdc1_vmmc"
#define QRES_SDC1_VQMMC    "sdc1_vqmmc"
