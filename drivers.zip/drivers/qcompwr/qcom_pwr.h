/* Shared interface between the QRB2210 power driver and its clients (eMMC, ...).
 * Clients find the driver by device interface GUID and send IOCTLs. */
#pragma once
#include <ntddk.h>
#include <initguid.h>

/* {5A3C1E2B-7D44-4F0A-9B6E-2C8D1F0A4B77} */
DEFINE_GUID(GUID_DEVINTERFACE_QCOM_PWR,
    0x5a3c1e2b, 0x7d44, 0x4f0a, 0x9b, 0x6e, 0x2c, 0x8d, 0x1f, 0x0a, 0x4b, 0x77);

typedef enum _QCOM_CLOCK_ID {
    QCOM_CLK_XO = 0,
    QCOM_CLK_SDC1_AHB,
    QCOM_CLK_SDC1_APPS,
    QCOM_CLK_SDC1_ICE_CORE,
    QCOM_CLK_SDC2_AHB,
    QCOM_CLK_SDC2_APPS,
    QCOM_CLK_COUNT
} QCOM_CLOCK_ID;

typedef enum _QCOM_RESET_ID { QCOM_RST_SDC1_BCR = 0, QCOM_RST_SDC2_BCR, QCOM_RST_COUNT } QCOM_RESET_ID;

/* PM4125 LDOs used by the RB1 board (qrb2210-rb1.dts) */
typedef enum _QCOM_REGULATOR_ID {
    QCOM_REG_PM4125_L20 = 0,  /* SDC1 VMMC  2.4-3.6 V */
    QCOM_REG_PM4125_L14,      /* SDC1 VQMMC 1.8 V fixed, NEVER turn off */
    QCOM_REG_PM4125_L21,      /* SDC2 VMMC  2.96-3.3 V */
    QCOM_REG_PM4125_L4,       /* SDC2 VQMMC 1.8-2.7 V */
    QCOM_REG_COUNT
} QCOM_REGULATOR_ID;

typedef struct _QCOM_PWR_REQUEST {
    ULONG Id;      /* QCOM_CLOCK_ID / QCOM_RESET_ID / QCOM_REGULATOR_ID */
    ULONG Enable;  /* 0 = off, 1 = on (ignored for reset pulse) */
    ULONG Value;   /* clock: Hz; regulator: microvolts */
} QCOM_PWR_REQUEST, *PQCOM_PWR_REQUEST;

#define IOCTL_QCOM_PWR_CLOCK_SET  CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_QCOM_PWR_RESET      CTL_CODE(FILE_DEVICE_UNKNOWN, 0x801, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_QCOM_PWR_REGULATOR  CTL_CODE(FILE_DEVICE_UNKNOWN, 0x802, METHOD_BUFFERED, FILE_ANY_ACCESS)
