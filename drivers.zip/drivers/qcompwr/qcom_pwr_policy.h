/* Board safety policy for the QRB2210 RB1 power service, kept separate so it can be unit-tested
 * on a host PC. Limits come from qrb2210-rb1.dts. */
#ifndef QCOM_PWR_POLICY_H
#define QCOM_PWR_POLICY_H
#include "qcom_pwr.h"

typedef struct { ULONG MinUv, MaxUv; BOOLEAN AlwaysOn; } QCOM_REG_LIMITS;

static const QCOM_REG_LIMITS g_QcomRegLimits[QCOM_REG_COUNT] = {
    /* L20 SDC1 VMMC  */ { 2400000, 3600000, FALSE },
    /* L14 SDC1 VQMMC */ { 1800000, 1800000, TRUE  },   /* "Broken hardware, never turn it off!" */
    /* L21 SDC2 VMMC  */ { 2960000, 3300000, FALSE },
    /* L4  SDC2 VQMMC */ { 1800000, 2700000, FALSE },   /* capped to disable 3 V signalling */
};

typedef enum { QCOM_POLICY_OK = 0, QCOM_POLICY_DENIED, QCOM_POLICY_INVALID } QCOM_POLICY;

static FORCEINLINE QCOM_POLICY QcomRegulatorPolicy(ULONG Id, ULONG Enable, ULONG Uv)
{
    if (Id >= QCOM_REG_COUNT) return QCOM_POLICY_INVALID;
    if (!Enable) return g_QcomRegLimits[Id].AlwaysOn ? QCOM_POLICY_DENIED : QCOM_POLICY_OK;
    if (Uv < g_QcomRegLimits[Id].MinUv || Uv > g_QcomRegLimits[Id].MaxUv) return QCOM_POLICY_INVALID;
    return QCOM_POLICY_OK;
}

#define QCOM_MAX_SDC_RATE_HZ 384000000u
static FORCEINLINE QCOM_POLICY QcomClockPolicy(ULONG Id, ULONG Enable, ULONG Hz)
{
    if (Id >= QCOM_CLK_COUNT) return QCOM_POLICY_INVALID;
    if (Enable && Id != QCOM_CLK_XO && Hz > QCOM_MAX_SDC_RATE_HZ) return QCOM_POLICY_INVALID;
    return QCOM_POLICY_OK;
}
#endif
