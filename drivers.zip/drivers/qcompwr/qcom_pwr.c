/*
 * QRB2210 platform resource service (KMDF). Policy, ownership and reference counting live in
 * qcom_res.c (host-tested); this file is the Windows shell plus the hardware back end, which is
 * NOT implemented (TODO(HW)): GCC clock/reset registers and the RPM regulator protocol.
 */
#include <ntddk.h>
#include <wdf.h>
#include "qcom_pwr.h"
#include "qcom_res_table.h"

#define GCC_MIN_LEN 0x1f0000UL

typedef struct _PWR_CONTEXT {
    PUCHAR       Gcc;
    SIZE_T       GccLength;
    WDFWAITLOCK  Lock;           /* serialises the registry; backend calls may block at PASSIVE_LEVEL */
    RES_REGISTRY Reg;
} PWR_CONTEXT, *PPWR_CONTEXT;
WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(PWR_CONTEXT, PwrCtx)

typedef struct _FILE_CONTEXT { int ClientId; } FILE_CONTEXT, *PFILE_CONTEXT;
WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(FILE_CONTEXT, FileCtx)

DRIVER_INITIALIZE                   DriverEntry;
EVT_WDF_DRIVER_DEVICE_ADD           PwrDeviceAdd;
EVT_WDF_DEVICE_PREPARE_HARDWARE     PwrPrepareHardware;
EVT_WDF_DEVICE_RELEASE_HARDWARE     PwrReleaseHardware;
EVT_WDF_DEVICE_FILE_CREATE          PwrFileCreate;
EVT_WDF_FILE_CLEANUP                PwrFileCleanup;
EVT_WDF_IO_QUEUE_IO_DEVICE_CONTROL  PwrIoctl;

/* ---- hardware back end: NOT IMPLEMENTED ---- */
static NTSTATUS HwClockSet(PPWR_CONTEXT c, ULONG hw, ULONG on, ULONG hz)
{
    /* TODO(HW): program GCC branch (CBCR) and RCG for `hw`; poll CLK_OFF; SDCC1_APPS rates
     * 100/192/384 MHz need the VDDCX corner voted first. */
    UNREFERENCED_PARAMETER(c); UNREFERENCED_PARAMETER(hw); UNREFERENCED_PARAMETER(on); UNREFERENCED_PARAMETER(hz);
    return STATUS_NOT_IMPLEMENTED;
}
static NTSTATUS HwResetPulse(PPWR_CONTEXT c, ULONG hw)
{
    /* TODO(HW): set/clear the BCR bit for GCC_SDCC{1,2}_BCR with the required delay. */
    UNREFERENCED_PARAMETER(c); UNREFERENCED_PARAMETER(hw);
    return STATUS_NOT_IMPLEMENTED;
}
static NTSTATUS HwRegulatorSet(PPWR_CONTEXT c, ULONG hw, ULONG on, ULONG uv)
{
    /* TODO(HW): RPM request for PM4125 LDO `hw` over SMD/GLINK (qcom,rpm-pm2250-regulators). */
    UNREFERENCED_PARAMETER(c); UNREFERENCED_PARAMETER(hw); UNREFERENCED_PARAMETER(on); UNREFERENCED_PARAMETER(uv);
    return STATUS_NOT_IMPLEMENTED;
}

static int ToRes(NTSTATUS st)
{
    if (NT_SUCCESS(st)) return RES_OK;
    return st == STATUS_NOT_IMPLEMENTED ? RES_E_NOTIMPL : RES_E_HW;
}
static int BeClock(void *Ctx, u32 Hw, u32 En, u32 Hz)  { return ToRes(HwClockSet((PPWR_CONTEXT)Ctx, Hw, En, Hz)); }
static int BeReset(void *Ctx, u32 Hw)                  { return ToRes(HwResetPulse((PPWR_CONTEXT)Ctx, Hw)); }
static int BeReg(void *Ctx, u32 Hw, u32 En, u32 Uv)    { return ToRes(HwRegulatorSet((PPWR_CONTEXT)Ctx, Hw, En, Uv)); }

static NTSTATUS ResToNt(int rc)
{
    switch (rc) {
    case RES_OK:          return STATUS_SUCCESS;
    case RES_E_NOENT:     return STATUS_OBJECT_NAME_NOT_FOUND;
    case RES_E_RANGE:
    case RES_E_TYPE:      return STATUS_INVALID_PARAMETER;
    case RES_E_BUSY:      return STATUS_DEVICE_BUSY;
    case RES_E_NOTHELD:   return STATUS_INVALID_DEVICE_STATE;
    case RES_E_NOCLIENT:  return STATUS_INSUFFICIENT_RESOURCES;
    case RES_E_NOTIMPL:   return STATUS_NOT_IMPLEMENTED;
    default:              return STATUS_IO_DEVICE_ERROR;
    }
}

NTSTATUS DriverEntry(_In_ PDRIVER_OBJECT Drv, _In_ PUNICODE_STRING Reg)
{
    WDF_DRIVER_CONFIG cfg;
    WDF_DRIVER_CONFIG_INIT(&cfg, PwrDeviceAdd);
    return WdfDriverCreate(Drv, Reg, WDF_NO_OBJECT_ATTRIBUTES, &cfg, WDF_NO_HANDLE);
}

NTSTATUS PwrDeviceAdd(_In_ WDFDRIVER Drv, _Inout_ PWDFDEVICE_INIT Init)
{
    NTSTATUS st; WDFDEVICE dev; WDF_OBJECT_ATTRIBUTES a, fa;
    WDF_PNPPOWER_EVENT_CALLBACKS pnp; WDF_IO_QUEUE_CONFIG q; WDF_FILE_OBJECT_CONFIG fc;
    PPWR_CONTEXT c;
    DECLARE_CONST_UNICODE_STRING(sddl, L"D:P(A;;GA;;;SY)(A;;GA;;;BA)");   /* kernel/admin only */
    UNREFERENCED_PARAMETER(Drv);

    st = WdfDeviceInitAssignSDDLString(Init, &sddl);
    if (!NT_SUCCESS(st)) return st;

    WDF_PNPPOWER_EVENT_CALLBACKS_INIT(&pnp);
    pnp.EvtDevicePrepareHardware = PwrPrepareHardware;
    pnp.EvtDeviceReleaseHardware = PwrReleaseHardware;
    WdfDeviceInitSetPnpPowerEventCallbacks(Init, &pnp);

    WDF_FILE_OBJECT_CONFIG_INIT(&fc, PwrFileCreate, NULL, PwrFileCleanup);
    WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&fa, FILE_CONTEXT);
    WdfDeviceInitSetFileObjectConfig(Init, &fc, &fa);        /* one client slot per open handle */

    WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&a, PWR_CONTEXT);
    st = WdfDeviceCreate(&Init, &a, &dev);
    if (!NT_SUCCESS(st)) return st;
    c = PwrCtx(dev);

    st = WdfWaitLockCreate(WDF_NO_OBJECT_ATTRIBUTES, &c->Lock);
    if (!NT_SUCCESS(st)) return st;
    st = WdfDeviceCreateDeviceInterface(dev, &GUID_DEVINTERFACE_QCOM_PWR, NULL);
    if (!NT_SUCCESS(st)) return st;

    WDF_IO_QUEUE_CONFIG_INIT_DEFAULT_QUEUE(&q, WdfIoQueueDispatchSequential);
    q.EvtIoDeviceControl = PwrIoctl;
    return WdfIoQueueCreate(dev, &q, WDF_NO_OBJECT_ATTRIBUTES, WDF_NO_HANDLE);
}

NTSTATUS PwrPrepareHardware(_In_ WDFDEVICE Dev, _In_ WDFCMRESLIST Raw, _In_ WDFCMRESLIST Tr)
{
    PPWR_CONTEXT c = PwrCtx(Dev);
    ULONG i, n = WdfCmResourceListGetCount(Tr);
    RES_BACKEND be; int rc;
    UNREFERENCED_PARAMETER(Raw);

    for (i = 0; i < n; i++) {
        PCM_PARTIAL_RESOURCE_DESCRIPTOR d = WdfCmResourceListGetDescriptor(Tr, i);
        if (d && d->Type == CmResourceTypeMemory && !c->Gcc) {
            if (d->u.Memory.Length < GCC_MIN_LEN) return STATUS_DEVICE_CONFIGURATION_ERROR;
            c->GccLength = d->u.Memory.Length;
            c->Gcc = MmMapIoSpaceEx(d->u.Memory.Start, c->GccLength, PAGE_READWRITE | PAGE_NOCACHE);
            if (!c->Gcc) return STATUS_INSUFFICIENT_RESOURCES;
        }
    }
    if (!c->Gcc) return STATUS_DEVICE_CONFIGURATION_ERROR;

    /* TODO(HW): open the RPM transport (SMD/GLINK channel "rpm_requests") before this. */
    be.Clock = BeClock; be.Reset = BeReset; be.Regulator = BeReg; be.Ctx = c;
    rc = res_init(&c->Reg, g_BoardResources, (u32)BOARD_RES_COUNT, &be);
    if (rc != RES_OK) return ResToNt(rc);        /* cannot guarantee the always-on rails: do not start */
    if (c->Reg.Adopted) KdPrint(("QCOMPWR: %lu always-on rail(s) assumed on (backend not implemented)\n", c->Reg.Adopted));
    return STATUS_SUCCESS;
}

NTSTATUS PwrReleaseHardware(_In_ WDFDEVICE Dev, _In_ WDFCMRESLIST Tr)
{
    PPWR_CONTEXT c = PwrCtx(Dev);
    UNREFERENCED_PARAMETER(Tr);
    if (c->Gcc) { MmUnmapIoSpace(c->Gcc, c->GccLength); c->Gcc = NULL; }
    return STATUS_SUCCESS;
}

VOID PwrFileCreate(_In_ WDFDEVICE Dev, _In_ WDFREQUEST Req, _In_ WDFFILEOBJECT File)
{
    PPWR_CONTEXT c = PwrCtx(Dev);
    int id;
    WdfWaitLockAcquire(c->Lock, NULL);
    id = res_client_open(&c->Reg);
    WdfWaitLockRelease(c->Lock);
    if (id < 0) { WdfRequestComplete(Req, STATUS_INSUFFICIENT_RESOURCES); return; }
    FileCtx(File)->ClientId = id;
    WdfRequestComplete(Req, STATUS_SUCCESS);
}

VOID PwrFileCleanup(_In_ WDFFILEOBJECT File)
{
    PPWR_CONTEXT c = PwrCtx(WdfFileObjectGetDevice(File));
    PFILE_CONTEXT f = FileCtx(File);
    if (f->ClientId <= 0) return;
    WdfWaitLockAcquire(c->Lock, NULL);
    (void)res_client_close(&c->Reg, f->ClientId);     /* releases everything this handle held */
    WdfWaitLockRelease(c->Lock);
    f->ClientId = 0;
}

VOID PwrIoctl(_In_ WDFQUEUE Q, _In_ WDFREQUEST Req, _In_ size_t OutLen, _In_ size_t InLen, _In_ ULONG Code)
{
    PPWR_CONTEXT c = PwrCtx(WdfIoQueueGetDevice(Q));
    PFILE_CONTEXT f = FileCtx(WdfRequestGetFileObject(Req));
    PQCOM_RES_REQUEST r = NULL;
    NTSTATUS st; int idx, rc;
    UNREFERENCED_PARAMETER(OutLen);

    if (InLen < sizeof(*r)) { WdfRequestComplete(Req, STATUS_BUFFER_TOO_SMALL); return; }
    st = WdfRequestRetrieveInputBuffer(Req, sizeof(*r), (PVOID *)&r, NULL);
    if (!NT_SUCCESS(st)) { WdfRequestComplete(Req, st); return; }
    r->Name[QCOM_RES_NAME_MAX - 1] = '\0';                /* never trust a caller-supplied string */

    WdfWaitLockAcquire(c->Lock, NULL);
    idx = res_lookup(&c->Reg, r->Name);
    if (idx < 0) {
        rc = idx;
    } else switch (Code) {
        case IOCTL_QCOM_RES_ACQUIRE: rc = res_acquire(&c->Reg, f->ClientId, idx, r->Value); break;
        case IOCTL_QCOM_RES_RELEASE: rc = res_release(&c->Reg, f->ClientId, idx); break;
        case IOCTL_QCOM_RES_RESET:   rc = res_reset(&c->Reg, f->ClientId, idx); break;
        default: rc = RES_E_TYPE; st = STATUS_INVALID_DEVICE_REQUEST;
    }
    WdfWaitLockRelease(c->Lock);

    if (Code != IOCTL_QCOM_RES_ACQUIRE && Code != IOCTL_QCOM_RES_RELEASE && Code != IOCTL_QCOM_RES_RESET)
        st = STATUS_INVALID_DEVICE_REQUEST;
    else
        st = ResToNt(rc);
    WdfRequestComplete(Req, st);
}
