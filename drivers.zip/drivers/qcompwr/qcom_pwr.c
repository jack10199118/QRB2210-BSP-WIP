/*
 * QRB2210 power/clock/regulator service driver (skeleton).
 *
 * Maps GCC (0x01400000) for clocks/resets and will talk to the RPM for the
 * PM4125 regulators. The board policy from qrb2210-rb1.dts is enforced HERE so
 * clients cannot violate it. Hardware access is NOT implemented: see TODO(HW).
 */
#include <ntddk.h>
#include <wdf.h>
#include "qcom_pwr.h"
#include "qcom_pwr_policy.h"

#define GCC_MIN_LEN 0x1f0000UL

typedef struct _PWR_CONTEXT {
    PUCHAR Gcc;
    SIZE_T GccLength;
    ULONG  RegOn[QCOM_REG_COUNT];
    ULONG  RegUv[QCOM_REG_COUNT];
    ULONG  ClkOn[QCOM_CLK_COUNT];
} PWR_CONTEXT, *PPWR_CONTEXT;
WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(PWR_CONTEXT, PwrCtx)

DRIVER_INITIALIZE               DriverEntry;
EVT_WDF_DRIVER_DEVICE_ADD       PwrDeviceAdd;
EVT_WDF_DEVICE_PREPARE_HARDWARE PwrPrepareHardware;
EVT_WDF_DEVICE_RELEASE_HARDWARE PwrReleaseHardware;
EVT_WDF_IO_QUEUE_IO_DEVICE_CONTROL PwrIoctl;

NTSTATUS DriverEntry(_In_ PDRIVER_OBJECT Drv, _In_ PUNICODE_STRING Reg)
{
    WDF_DRIVER_CONFIG cfg;
    WDF_DRIVER_CONFIG_INIT(&cfg, PwrDeviceAdd);
    return WdfDriverCreate(Drv, Reg, WDF_NO_OBJECT_ATTRIBUTES, &cfg, WDF_NO_HANDLE);
}

NTSTATUS PwrDeviceAdd(_In_ WDFDRIVER Drv, _Inout_ PWDFDEVICE_INIT Init)
{
    NTSTATUS st; WDFDEVICE dev; WDF_OBJECT_ATTRIBUTES a;
    WDF_PNPPOWER_EVENT_CALLBACKS pnp; WDF_IO_QUEUE_CONFIG q;
    DECLARE_CONST_UNICODE_STRING(sddl, L"D:P(A;;GA;;;SY)(A;;GA;;;BA)");   /* kernel/admin only */
    UNREFERENCED_PARAMETER(Drv);

    st = WdfDeviceInitAssignSDDLString(Init, &sddl);
    if (!NT_SUCCESS(st)) return st;

    WDF_PNPPOWER_EVENT_CALLBACKS_INIT(&pnp);
    pnp.EvtDevicePrepareHardware = PwrPrepareHardware;
    pnp.EvtDeviceReleaseHardware = PwrReleaseHardware;
    WdfDeviceInitSetPnpPowerEventCallbacks(Init, &pnp);

    WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&a, PWR_CONTEXT);
    st = WdfDeviceCreate(&Init, &a, &dev);
    if (!NT_SUCCESS(st)) return st;

    st = WdfDeviceCreateDeviceInterface(dev, &GUID_DEVINTERFACE_QCOM_PWR, NULL);
    if (!NT_SUCCESS(st)) return st;

    WDF_IO_QUEUE_CONFIG_INIT_DEFAULT_QUEUE(&q, WdfIoQueueDispatchSequential);
    q.EvtIoDeviceControl = PwrIoctl;
    return WdfIoQueueCreate(dev, &q, WDF_NO_OBJECT_ATTRIBUTES, WDF_NO_HANDLE);
}

NTSTATUS PwrPrepareHardware(_In_ WDFDEVICE Dev, _In_ WDFCMRESLIST Raw, _In_ WDFCMRESLIST Tr)
{
    PPWR_CONTEXT c = PwrCtx(Dev);
    ULONG i, n = WdfCmResourceListGetCount(Tr);
    UNREFERENCED_PARAMETER(Raw);
    for (i = 0; i < n; i++) {
        PCM_PARTIAL_RESOURCE_DESCRIPTOR d = WdfCmResourceListGetDescriptor(Tr, i);
        if (d && d->Type == CmResourceTypeMemory && !c->Gcc) {
            if (d->u.Memory.Length < GCC_MIN_LEN) return STATUS_DEVICE_CONFIGURATION_ERROR;
            c->GccLength = d->u.Memory.Length;
            c->Gcc = MmMapIoSpaceEx(d->u.Memory.Start, c->GccLength, PAGE_READWRITE | PAGE_NOCACHE);
            if (!c->Gcc) return STATUS_INSUFFICIENT_RESOURCES;
        }
    }
    /* TODO(HW): open the RPM transport (SMD/GLINK channel "rpm_requests") here. */
    return c->Gcc ? STATUS_SUCCESS : STATUS_DEVICE_CONFIGURATION_ERROR;
}

NTSTATUS PwrReleaseHardware(_In_ WDFDEVICE Dev, _In_ WDFCMRESLIST Tr)
{
    PPWR_CONTEXT c = PwrCtx(Dev);
    UNREFERENCED_PARAMETER(Tr);
    if (c->Gcc) { MmUnmapIoSpace(c->Gcc, c->GccLength); c->Gcc = NULL; }
    return STATUS_SUCCESS;
}

/* ---- hardware back ends: NOT IMPLEMENTED ---- */
static NTSTATUS HwClockSet(PPWR_CONTEXT c, ULONG id, ULONG on, ULONG hz)
{
    /* TODO(HW): program GCC branch (CBCR) and RCG for `id`; poll CLK_OFF; honour
     * rates 100/192/384 MHz for SDCC1_APPS (VDDCX vote must precede rate change). */
    UNREFERENCED_PARAMETER(c); UNREFERENCED_PARAMETER(id); UNREFERENCED_PARAMETER(on); UNREFERENCED_PARAMETER(hz);
    return STATUS_NOT_IMPLEMENTED;
}
static NTSTATUS HwResetPulse(PPWR_CONTEXT c, ULONG id)
{
    /* TODO(HW): set/clear BCR bit for GCC_SDCC{1,2}_BCR with required delay. */
    UNREFERENCED_PARAMETER(c); UNREFERENCED_PARAMETER(id);
    return STATUS_NOT_IMPLEMENTED;
}
static NTSTATUS HwRegulatorSet(PPWR_CONTEXT c, ULONG id, ULONG on, ULONG uv)
{
    /* TODO(HW): send an RPM "ldoa/smpa" request for PM4125 LDO `id` over SMD/GLINK
     * (qcom,rpm-pm2250-regulators): enable, microvolts, headroom. */
    UNREFERENCED_PARAMETER(c); UNREFERENCED_PARAMETER(id); UNREFERENCED_PARAMETER(on); UNREFERENCED_PARAMETER(uv);
    return STATUS_NOT_IMPLEMENTED;
}

VOID PwrIoctl(_In_ WDFQUEUE Q, _In_ WDFREQUEST Req, _In_ size_t OutLen, _In_ size_t InLen, _In_ ULONG Code)
{
    PPWR_CONTEXT c = PwrCtx(WdfIoQueueGetDevice(Q));
    PQCOM_PWR_REQUEST r = NULL;
    NTSTATUS st;
    UNREFERENCED_PARAMETER(OutLen);

    if (InLen < sizeof(*r)) { WdfRequestComplete(Req, STATUS_BUFFER_TOO_SMALL); return; }
    st = WdfRequestRetrieveInputBuffer(Req, sizeof(*r), (PVOID *)&r, NULL);
    if (!NT_SUCCESS(st)) { WdfRequestComplete(Req, st); return; }

    switch (Code) {
    case IOCTL_QCOM_PWR_CLOCK_SET:
        if (QcomClockPolicy(r->Id, r->Enable, r->Value) != QCOM_POLICY_OK) { st = STATUS_INVALID_PARAMETER; break; }
        st = HwClockSet(c, r->Id, r->Enable, r->Value);
        if (NT_SUCCESS(st)) c->ClkOn[r->Id] = r->Enable;
        break;
    case IOCTL_QCOM_PWR_RESET:
        if (r->Id >= QCOM_RST_COUNT) { st = STATUS_INVALID_PARAMETER; break; }
        st = HwResetPulse(c, r->Id);
        break;
    case IOCTL_QCOM_PWR_REGULATOR:
        switch (QcomRegulatorPolicy(r->Id, r->Enable, r->Value)) {
        case QCOM_POLICY_DENIED:  st = STATUS_ACCESS_DENIED; break;     /* board rule: never off */
        case QCOM_POLICY_INVALID: st = STATUS_INVALID_PARAMETER; break; /* outside DT limits */
        default:
            st = HwRegulatorSet(c, r->Id, r->Enable, r->Value);
            if (NT_SUCCESS(st)) { c->RegOn[r->Id] = r->Enable; c->RegUv[r->Id] = r->Value; }
        }
        break;
    default:
        st = STATUS_INVALID_DEVICE_REQUEST;
    }
    WdfRequestComplete(Req, st);
}
