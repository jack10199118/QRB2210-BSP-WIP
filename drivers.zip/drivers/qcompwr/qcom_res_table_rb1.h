#ifndef QCOM_RES_TABLE_RB1_H
#define QCOM_RES_TABLE_RB1_H
/* Qualcomm RB1 board (qrb2210-rb1.dts). Selected with -DQCOM_BOARD_RB1. */

static const RES_DESC g_BoardResources[] = {
    { "xo",            RES_CLOCK,     QHW_CLK_XO,           0,       0,          0 },
    { "sdc1_ahb",      RES_CLOCK,     QHW_CLK_SDC1_AHB,     0,       0,          0 },
    { "sdc1_apps",     RES_CLOCK,     QHW_CLK_SDC1_APPS,    100000,  384000000u, 0 },
    { "sdc1_ice_core", RES_CLOCK,     QHW_CLK_SDC1_ICE_CORE,0,       0,          0 },
    { "sdc2_ahb",      RES_CLOCK,     QHW_CLK_SDC2_AHB,     0,       0,          0 },
    { "sdc2_apps",     RES_CLOCK,     QHW_CLK_SDC2_APPS,    100000,  384000000u, 0 },
    { "sdc1_bcr",      RES_RESET,     QHW_RST_SDC1_BCR,     0,       0,          0 },
    { "sdc2_bcr",      RES_RESET,     QHW_RST_SDC2_BCR,     0,       0,          0 },
    /* PM4125 LDOs; limits from the board DTS */
    { "sdc1_vmmc",     RES_REGULATOR, QHW_REG_PM4125_L20,   2400000, 3600000,    0 },
    { "sdc1_vqmmc",    RES_REGULATOR, QHW_REG_PM4125_L14,   1800000, 1800000,    1 },  /* "never turn it off" */
    { "sdc2_vmmc",     RES_REGULATOR, QHW_REG_PM4125_L21,   2960000, 3300000,    0 },
    { "sdc2_vqmmc",    RES_REGULATOR, QHW_REG_PM4125_L4,    1800000, 2700000,    0 },  /* 3 V signalling disabled */
};
#define BOARD_RES_COUNT (sizeof(g_BoardResources) / sizeof(g_BoardResources[0]))
#endif
