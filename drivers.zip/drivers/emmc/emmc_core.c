#include "emmc_core.h"

#ifdef EMMC_HOST_TEST
extern u32  sim_rd(u32 off, int bytes);
extern void sim_wr(u32 off, int bytes, u32 val);
#define R8(c,o)   ((u8)sim_rd((o),1))
#define R16(c,o)  ((u16)sim_rd((o),2))
#define R32(c,o)  sim_rd((o),4)
#define W8(c,o,v)  sim_wr((o),1,(v))
#define W16(c,o,v) sim_wr((o),2,(v))
#define W32(c,o,v) sim_wr((o),4,(v))
#else
#define R8(c,o)   READ_REGISTER_UCHAR((PUCHAR)(c)->Regs + (o))
#define R16(c,o)  READ_REGISTER_USHORT((PUSHORT)((PUCHAR)(c)->Regs + (o)))
#define R32(c,o)  READ_REGISTER_ULONG((PULONG)((PUCHAR)(c)->Regs + (o)))
#define W8(c,o,v)  WRITE_REGISTER_UCHAR((PUCHAR)(c)->Regs + (o), (u8)(v))
#define W16(c,o,v) WRITE_REGISTER_USHORT((PUSHORT)((PUCHAR)(c)->Regs + (o)), (u16)(v))
#define W32(c,o,v) WRITE_REGISTER_ULONG((PULONG)((PUCHAR)(c)->Regs + (o)), (u32)(v))
#endif

static void delay(EMMC_CORE *c, u32 us) { if (c->DelayUs) c->DelayUs(c->Ctx, us); }

static int poll_int(EMMC_CORE *c, u32 mask, u32 timeout_us, u32 *seen)
{
    u32 waited = 0, s;
    for (;;) {
        s = R32(c, SD_INTSTAT);
        if (s & (mask | SD_INT_ERROR)) { *seen = s; return EMMC_OK; }
        if (waited >= timeout_us) return EMMC_E_TIMEOUT;
        delay(c, 100); waited += 100;
    }
}

static int map_err(u32 s)
{
    if (s & (SD_INT_CMD_TMO | SD_INT_DATA_TMO)) return EMMC_E_TIMEOUT;
    if (s & SD_INT_ADMA_ERR)                    return EMMC_E_ADMA;
    if (s & SD_INT_ERR_MASK)                    return EMMC_E_CRC;
    return EMMC_E_IO;
}

int emmc_reset(EMMC_CORE *c, u8 mask)
{
    u32 i;
    W8(c, SD_SWRESET, mask);
    for (i = 0; i < 100; i++) {
        if (!(R8(c, SD_SWRESET) & mask)) return EMMC_OK;
        delay(c, 1000);
    }
    return EMMC_E_TIMEOUT;
}

int emmc_set_power(EMMC_CORE *c, u32 mv)
{
    u8 sel;
    (void)c;
    switch (mv) { case 1800: sel = 5; break; case 3000: sel = 6; break; case 3300: sel = 7; break;
                  default: return EMMC_E_BADARG; }
    W8(c, SD_POWER, 0);
    W8(c, SD_POWER, (u8)((sel << 1) | 1));
    return EMMC_OK;
}

int emmc_set_clock(EMMC_CORE *c, u32 hz)
{
    u32 n = 0, i; u16 clk;
    W16(c, SD_CLKCTL, 0);
    if (hz == 0) return EMMC_OK;
    if (c->SetRate) {
        int r = c->SetRate(c->Ctx, hz);        /* platform sets core clock = card clock */
        if (r) return r;
    } else if (hz < c->BaseClockHz) {
        n = (c->BaseClockHz + 2 * hz - 1) / (2 * hz);     /* freq = base / (2n) */
        if (n > 1023) n = 1023;
    }
    clk = (u16)(((n & 0xFF) << 8) | (((n >> 8) & 3) << 6) | 1);   /* internal clock enable */
    W16(c, SD_CLKCTL, clk);
    for (i = 0; i < 20; i++) {
        if (R16(c, SD_CLKCTL) & 2) { W16(c, SD_CLKCTL, clk | 4); return EMMC_OK; }  /* stable -> SD clock on */
        delay(c, 1000);
    }
    return EMMC_E_TIMEOUT;
}

void emmc_set_bus(EMMC_CORE *c, u32 width, int highspeed)
{
    u8 h = R8(c, SD_HOSTCTL);
    h &= (u8)~((1 << 1) | (1 << 5) | (1 << 2));            /* 4-bit, 8-bit, high-speed */
    if (width == 4) h |= (1 << 1);
    if (width == 8) h |= (1 << 5);
    if (highspeed)  h |= (1 << 2);
    W8(c, SD_HOSTCTL, h);
    c->BusWidth = width;
}

/* ADMA2, 32-bit descriptors: attr(16) len(16) addr(32). Chunks of 32 KiB. */
typedef struct { u16 attr; u16 len; u32 addr; } ADMA2_DESC;
#define ADMA_VALID 0x01
#define ADMA_END   0x02
#define ADMA_TRAN  0x20
#define ADMA_CHUNK 0x8000u

int emmc_build_adma2(void *table, u32 table_bytes, u64 buf_la, u32 len, u32 *used)
{
    ADMA2_DESC *d = (ADMA2_DESC *)table;
    u32 max = table_bytes / (u32)sizeof(ADMA2_DESC), n = 0;
    if (len == 0 || (buf_la & 3) || (buf_la + len) > 0x100000000ULL) return EMMC_E_BADARG;
    while (len) {
        u32 part = len > ADMA_CHUNK ? ADMA_CHUNK : len;
        if (n >= max) return EMMC_E_BADARG;
        d[n].addr = (u32)buf_la;
        d[n].len  = (u16)part;
        d[n].attr = ADMA_VALID | ADMA_TRAN;
        buf_la += part; len -= part; n++;
    }
    d[n - 1].attr |= ADMA_END;
    if (used) *used = n;
    return EMMC_OK;
}

static int rsp_flags(EMMC_RSP r)
{
    switch (r) { case RSP_NONE: return 0x00; case RSP_R1: return 0x1A; case RSP_R1B: return 0x1B;
                 case RSP_R2: return 0x09; default: return 0x02; }   /* R3: no CRC/index check */
}

static int do_cmd(EMMC_CORE *c, u32 idx, u32 arg, EMMC_RSP rsp, u16 xmode, int data)
{
    u32 s, waited = 0, inhibit = 1u | ((data || rsp == RSP_R1B) ? 2u : 0u);
    int r;

    while (R32(c, SD_PRESENT) & inhibit) {
        if (waited >= 100000) return EMMC_E_TIMEOUT;
        delay(c, 100); waited += 100;
    }
    W32(c, SD_INTSTAT, 0xFFFFFFFFu);
    W32(c, SD_ARG, arg);
    W16(c, SD_XFERMODE, xmode);
    W16(c, SD_CMD, (u16)((idx << 8) | rsp_flags(rsp) | (data ? 0x20 : 0)));

    r = poll_int(c, SD_INT_CMDDONE, 500000, &s);
    if (r) { emmc_reset(c, SD_RESET_CMD | SD_RESET_DAT); return r; }
    if (s & SD_INT_ERROR) { emmc_reset(c, SD_RESET_CMD | SD_RESET_DAT); return map_err(s); }
    W32(c, SD_INTSTAT, SD_INT_CMDDONE);

    if (rsp == RSP_R2) {
        c->Resp[0] = R32(c, SD_RESP);      c->Resp[1] = R32(c, SD_RESP + 4);
        c->Resp[2] = R32(c, SD_RESP + 8);  c->Resp[3] = R32(c, SD_RESP + 12);
    } else if (rsp != RSP_NONE) {
        c->Resp[0] = R32(c, SD_RESP);
    }

    if (data || rsp == RSP_R1B) {          /* wait for transfer-complete (data done / busy released) */
        r = poll_int(c, SD_INT_XFERDONE, data ? 2000000 : 3000000, &s);
        if (r || (s & SD_INT_ERROR)) {
            int e = r ? r : map_err(s);
            emmc_reset(c, SD_RESET_CMD | SD_RESET_DAT);
            return e;
        }
        W32(c, SD_INTSTAT, SD_INT_XFERDONE);
    }
    return EMMC_OK;
}

int emmc_cmd(EMMC_CORE *c, u32 idx, u32 arg, EMMC_RSP rsp)
{
    return do_cmd(c, idx, arg, rsp, 0, 0);
}

int emmc_cmd_data(EMMC_CORE *c, u32 idx, u32 arg, EMMC_RSP rsp,
                  u32 blocks, u64 buf_la, int read, int auto_cmd12)
{
    u16 mode = 0x01 | 0x02;                                 /* DMA enable, block count enable */
    u32 used, bytes = blocks * 512u;
    int r;
    if (blocks == 0 || blocks > 0xFFFF) return EMMC_E_BADARG;
    r = emmc_build_adma2(c->AdmaVa, c->AdmaBytes, buf_la, bytes, &used);
    if (r) return r;
    if (read) mode |= 0x10;
    if (blocks > 1) mode |= 0x20 | (auto_cmd12 ? 0x04 : 0);
    W32(c, SD_ADMAADDR, (u32)c->AdmaLa);
    W32(c, SD_ADMAADDR + 4, (u32)(c->AdmaLa >> 32));
    W8(c, SD_HOSTCTL, (u8)((R8(c, SD_HOSTCTL) & ~0x18) | 0x10));   /* DMA select = ADMA2 32-bit */
    W16(c, SD_BLKSIZE, 512);
    W16(c, SD_BLKCOUNT, blocks);
    W8(c, SD_TIMEOUT, 0x0E);
    return do_cmd(c, idx, arg, rsp, mode, 1);
}

static int switch_ext(EMMC_CORE *c, u32 index, u32 value)
{
    int r = emmc_cmd(c, 6, (3u << 24) | (index << 16) | (value << 8) | 1u, RSP_R1B);
    if (r) return r;
    if (c->Resp[0] & 0x80u) return EMMC_E_CARD;             /* SWITCH_ERROR */
    return EMMC_OK;
}

int emmc_card_init(EMMC_CORE *c, u64 scratch_la, u8 *scratch_va)
{
    u32 i; int r;

    r = emmc_reset(c, SD_RESET_ALL);                       if (r) return r;
    if (c->AfterReset) c->AfterReset(c->Ctx);
    W32(c, SD_INTEN, 0xFFFFFFFFu);                         /* status bits visible to polling */
    W32(c, SD_SIGEN, 0);                                   /* no IRQ signalling during polled init */
    r = emmc_set_power(c, 1800);                           if (r) return r;
    delay(c, 10000);                                       /* let the pwr_irq handshake finish (TODO(HW): wait on an event) */
    r = emmc_set_clock(c, 400000);                         if (r) return r;
    emmc_set_bus(c, 1, 0);
    delay(c, 2000);

    r = emmc_cmd(c, 0, 0, RSP_NONE);                       if (r) return r;
    for (i = 0; i < 200; i++) {                            /* CMD1 until power-up bit */
        r = emmc_cmd(c, 1, 0x40FF8080u, RSP_R3);           if (r) return r;
        if (c->Resp[0] & 0x80000000u) break;
        delay(c, 5000);
    }
    if (i == 200) return EMMC_E_TIMEOUT;
    if (!(c->Resp[0] & 0x40000000u)) return EMMC_E_CARD;   /* require sector addressing (>2 GB) */

    r = emmc_cmd(c, 2, 0, RSP_R2);                         if (r) return r;
    c->Rca = 1;
    r = emmc_cmd(c, 3, c->Rca << 16, RSP_R1);              if (r) return r;
    r = emmc_cmd(c, 7, c->Rca << 16, RSP_R1B);             if (r) return r;

    r = emmc_cmd_data(c, 8, 0, RSP_R1, 1, scratch_la, 1, 0);   /* EXT_CSD */
    if (r) return r;
    c->SectorCount = (u32)scratch_va[212] | ((u32)scratch_va[213] << 8) |
                     ((u32)scratch_va[214] << 16) | ((u32)scratch_va[215] << 24);
    c->BootSizeKb = (u32)scratch_va[226] * 128u;
    c->Partition = 0;

    r = switch_ext(c, 185, 1);                             if (r) return r;   /* HS_TIMING = high speed */
    r = switch_ext(c, 183, 2);                             if (r) return r;   /* BUS_WIDTH = 8-bit SDR */
    emmc_set_bus(c, 8, 1);
    r = emmc_set_clock(c, 52000000);                       if (r) return r;
    return emmc_cmd(c, 13, c->Rca << 16, RSP_R1);          /* confirm card still answers */
}

/* Select the partition that later reads/writes address, preserving the boot-enable bits. */
int emmc_select_partition(EMMC_CORE *c, u32 part, u64 scratch_la, u8 *scratch_va)
{
    u32 cfg; int r;
    if (part > 7) return EMMC_E_BADARG;
    r = emmc_cmd_data(c, 8, 0, RSP_R1, 1, scratch_la, 1, 0);      /* current EXT_CSD */
    if (r) return r;
    cfg = (scratch_va[179] & ~7u) | part;                          /* PARTITION_CONFIG[2:0] = PARTITION_ACCESS */
    r = switch_ext(c, 179, cfg);
    if (r) return r;
    c->Partition = part;
    return EMMC_OK;
}

int emmc_read(EMMC_CORE *c, u32 lba, u32 count, u64 buf_la)
{
    return emmc_cmd_data(c, count > 1 ? 18 : 17, lba, RSP_R1, count, buf_la, 1, 1);
}

int emmc_write(EMMC_CORE *c, u32 lba, u32 count, u64 buf_la)
{
    return emmc_cmd_data(c, count > 1 ? 25 : 24, lba, RSP_R1, count, buf_la, 0, 1);
}
