/*
 * KMDF eMMC host controller core for QRB2210 SDC1 (SDHCI-compatible window).
 * Scaffold: resource mapping, reset, interrupts, ADMA2 common buffer.
 * NOT a complete storage driver; see README for SDPORT integration.
 * All offsets below are from the SD Host Controller Simplified Spec; verify
 * the Qualcomm host-register base offset (TODO(HW)).
 */
#include <ntddk.h>
#include <wdf.h>
#include "../qcompwr/qcom_pwr.h"
#include "emmc_core.h"
#include "emmc_ioctl.h"

#define EMMC_TAG 'cMME'

/* SDHCI register offsets (SD Host Controller Simplified Spec 4.x) */
#define SDHCI_ARGUMENT      0x08
#define SDHCI_XFER_MODE     0x0C
#define SDHCI_COMMAND       0x0E
#define SDHCI_RESPONSE      0x10
#define SDHCI_PRESENT_STATE 0x24
#define SDHCI_HOST_CTRL1    0x28
#define SDHCI_CLOCK_CTRL    0x2C
#define SDHCI_TIMEOUT_CTRL  0x2E
#define SDHCI_SW_RESET      0x2F
#define SDHCI_INT_STATUS    0x30
#define SDHCI_INT_ENABLE    0x34
#define SDHCI_SIGNAL_ENABLE 0x38
#define SDHCI_ADMA_ADDR     0x58

#define SDHCI_RESET_ALL     0x01
#define SDHCI_INT_ALL_MASK  0xFFFFFFFFu

/* From qcm2290.dtsi sdhc_1 (mmc@4744000), "hc" region: standard SDHCI regs
 * start at the base of the window. Qualcomm core regs (DLL, PWRCTL, vendor
 * specific) are NOT standard: mirror Linux drivers/mmc/host/sdhci-msm.c. */
#define EMMC_HOST_REG_OFFSET 0x0

/* qcm2290.dtsi: hc_irq = SPI 348, pwr_irq = SPI 352; ACPI GSIV = SPI + 32 */
#define EMMC_GSIV_HC   380
#define EMMC_GSIV_PWR  384
#define EMMC_BASE_HC   0x04744000ULL

/* Qualcomm SDCC v5 core registers (offsets from the hc base).
 * RECALLED from Linux sdhci-msm.c (sdhci_msm_v5_offset); verify against your
 * copy of the kernel source before trusting any of them. */
#define MSM_DLL_CONFIG      0x200
#define MSM_DLL_STATUS      0x208
#define MSM_VENDOR_SPEC     0x20C
#define MSM_PWRCTL_STATUS   0x240
#define MSM_PWRCTL_MASK     0x244
#define MSM_PWRCTL_CLEAR    0x248
#define MSM_PWRCTL_CTL      0x24C
#define MSM_DDR_CONFIG      0x25C
#define PWRCTL_BUS_OFF      (1u << 0)
#define PWRCTL_BUS_ON       (1u << 1)
#define PWRCTL_IO_LOW       (1u << 2)
#define PWRCTL_IO_HIGH      (1u << 3)
#define PWRCTL_ACK_BUS_OK   (1u << 0)
#define PWRCTL_ACK_IO_OK    (1u << 2)
/* From qcm2290.dtsi sdhc_1 */
#define SDC1_DLL_CONFIG     0x000f642cu
#define SDC1_DDR_CONFIG     0x80040868u

/* RB1 board: SDC1 supplies (resource names; limits are enforced by the platform service) */
#define SDC1_VMMC_UV        2950000u
#define SDC1_VQMMC_LOW_UV   1800000u
#define SDC1_VQMMC_HIGH_UV  1800000u   /* L14 is fixed 1.8 V: no 3 V I/O switch on this board */

#define DATA_BUFFER_BYTES  65536
#define ADMA_TABLE_BYTES    (PAGE_SIZE)

typedef struct _EMMC_CONTEXT {
    PUCHAR        Regs;           /* mapped host registers */
    SIZE_T        RegLength;
    WDFINTERRUPT  HcInterrupt;    /* hc_irq: SDHCI events */
    WDFINTERRUPT  PwrInterrupt;   /* pwr_irq: bus power / voltage-switch handshake */
    WDFIOTARGET   PwrTarget;      /* QRB2210 power service */
    ULONG         PendingStatus;  /* written by ISR, consumed by DPC */
    WDFDMAENABLER DmaEnabler;
    WDFCOMMONBUFFER AdmaBuffer;
    PVOID         AdmaVa;
    PHYSICAL_ADDRESS AdmaLa;      /* device logical address (SMMU-aware) */
    WDFCOMMONBUFFER DataBuffer;   /* 64 KiB bounce buffer for the self-test / future I/O */
    PVOID         DataVa;
    PHYSICAL_ADDRESS DataLa;
    EMMC_CORE     Core;
    BOOLEAN       CardReady;
} EMMC_CONTEXT, *PEMMC_CONTEXT;
WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(EMMC_CONTEXT, EmmcCtx)

/* ---- register accessors (always use READ/WRITE_REGISTER_*) ---- */
static FORCEINLINE ULONG  Rd32(PEMMC_CONTEXT c, ULONG o){ return READ_REGISTER_ULONG((PULONG)(c->Regs+EMMC_HOST_REG_OFFSET+o)); }
static FORCEINLINE VOID   Wr32(PEMMC_CONTEXT c, ULONG o, ULONG v){ WRITE_REGISTER_ULONG((PULONG)(c->Regs+EMMC_HOST_REG_OFFSET+o), v); }
static FORCEINLINE UCHAR  Rd8 (PEMMC_CONTEXT c, ULONG o){ return READ_REGISTER_UCHAR(c->Regs+EMMC_HOST_REG_OFFSET+o); }
static FORCEINLINE VOID   Wr8 (PEMMC_CONTEXT c, ULONG o, UCHAR v){ WRITE_REGISTER_UCHAR(c->Regs+EMMC_HOST_REG_OFFSET+o, v); }

DRIVER_INITIALIZE               DriverEntry;
EVT_WDF_DRIVER_DEVICE_ADD       EmmcDeviceAdd;
EVT_WDF_DEVICE_PREPARE_HARDWARE EmmcPrepareHardware;
EVT_WDF_DEVICE_RELEASE_HARDWARE EmmcReleaseHardware;
EVT_WDF_DEVICE_D0_ENTRY         EmmcD0Entry;
EVT_WDF_DEVICE_D0_EXIT          EmmcD0Exit;
EVT_WDF_IO_QUEUE_IO_DEVICE_CONTROL EmmcIoctl;
EVT_WDF_INTERRUPT_ISR           EmmcIsr;
EVT_WDF_INTERRUPT_ISR           EmmcPwrIsr;
EVT_WDF_INTERRUPT_DPC           EmmcDpc;

/* ---- power service client ---- */
static NTSTATUS EmmcOpenPwr(WDFDEVICE Dev, PEMMC_CONTEXT c)
{
    PWSTR list = NULL; NTSTATUS st; UNICODE_STRING name;
    WDF_IO_TARGET_OPEN_PARAMS op;
    if (c->PwrTarget) return STATUS_SUCCESS;
    st = IoGetDeviceInterfaces(&GUID_DEVINTERFACE_QCOM_PWR, NULL, 0, &list);
    if (!NT_SUCCESS(st)) return st;
    if (!list || !*list) { if (list) ExFreePool(list); return STATUS_DEVICE_NOT_READY; }
    RtlInitUnicodeString(&name, list);
    st = WdfIoTargetCreate(Dev, WDF_NO_OBJECT_ATTRIBUTES, &c->PwrTarget);
    if (NT_SUCCESS(st)) {
        WDF_IO_TARGET_OPEN_PARAMS_INIT_OPEN_BY_NAME(&op, &name, GENERIC_READ | GENERIC_WRITE);
        st = WdfIoTargetOpen(c->PwrTarget, &op);
        if (!NT_SUCCESS(st)) { WdfObjectDelete(c->PwrTarget); c->PwrTarget = NULL; }
    }
    ExFreePool(list);
    return st;
}

static NTSTATUS EmmcRes(PEMMC_CONTEXT c, ULONG ioctl, const char *name, ULONG value)
{
    QCOM_RES_REQUEST r; WDF_MEMORY_DESCRIPTOR in; ULONG i;
    RtlZeroMemory(&r, sizeof(r));
    for (i = 0; name[i] && i < QCOM_RES_NAME_MAX - 1; i++) r.Name[i] = name[i];
    r.Value = value;
    WDF_MEMORY_DESCRIPTOR_INIT_BUFFER(&in, &r, sizeof(r));
    return WdfIoTargetSendIoctlSynchronously(c->PwrTarget, NULL, ioctl, &in, NULL, NULL, NULL);
}
#define ResAcquire(c, n, v) EmmcRes((c), IOCTL_QCOM_RES_ACQUIRE, (n), (v))
#define ResRelease(c, n)    EmmcRes((c), IOCTL_QCOM_RES_RELEASE, (n), 0)
#define ResReset(c, n)      EmmcRes((c), IOCTL_QCOM_RES_RESET, (n), 0)

NTSTATUS DriverEntry(_In_ PDRIVER_OBJECT Drv, _In_ PUNICODE_STRING Reg)
{
    WDF_DRIVER_CONFIG cfg;
    WDF_DRIVER_CONFIG_INIT(&cfg, EmmcDeviceAdd);
    return WdfDriverCreate(Drv, Reg, WDF_NO_OBJECT_ATTRIBUTES, &cfg, WDF_NO_HANDLE);
}

NTSTATUS EmmcDeviceAdd(_In_ WDFDRIVER Drv, _Inout_ PWDFDEVICE_INIT Init)
{
    NTSTATUS st;
    WDFDEVICE dev;
    WDF_OBJECT_ATTRIBUTES attr;
    WDF_PNPPOWER_EVENT_CALLBACKS pnp;
    WDF_DMA_ENABLER_CONFIG dc;
    PEMMC_CONTEXT c;
    WDF_IO_QUEUE_CONFIG q;
    DECLARE_CONST_UNICODE_STRING(sddl, L"D:P(A;;GA;;;SY)(A;;GA;;;BA)");
    UNREFERENCED_PARAMETER(Drv);

    st = WdfDeviceInitAssignSDDLString(Init, &sddl);          /* SYSTEM + Administrators only */
    if (!NT_SUCCESS(st)) return st;

    WDF_PNPPOWER_EVENT_CALLBACKS_INIT(&pnp);
    pnp.EvtDevicePrepareHardware = EmmcPrepareHardware;
    pnp.EvtDeviceReleaseHardware = EmmcReleaseHardware;
    pnp.EvtDeviceD0Entry         = EmmcD0Entry;
    pnp.EvtDeviceD0Exit          = EmmcD0Exit;
    WdfDeviceInitSetPnpPowerEventCallbacks(Init, &pnp);

    WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&attr, EMMC_CONTEXT);
    st = WdfDeviceCreate(&Init, &attr, &dev);          /* context: non-paged */
    if (!NT_SUCCESS(st)) return st;
    c = EmmcCtx(dev);

    /* Two interrupts: created in PrepareHardware, one per resource descriptor. */

    st = WdfDeviceCreateDeviceInterface(dev, &GUID_DEVINTERFACE_QRB2210_EMMC, NULL);
    if (!NT_SUCCESS(st)) return st;
    WDF_IO_QUEUE_CONFIG_INIT_DEFAULT_QUEUE(&q, WdfIoQueueDispatchSequential);
    q.EvtIoDeviceControl = EmmcIoctl;
    st = WdfIoQueueCreate(dev, &q, WDF_NO_OBJECT_ATTRIBUTES, WDF_NO_HANDLE);
    if (!NT_SUCCESS(st)) return st;
    /* ADMA2 supports 32-bit (or 64-bit with v4 mode); start with 32-bit. */
    WDF_DMA_ENABLER_CONFIG_INIT(&dc, WdfDmaProfileScatterGather, 0x10000 * 32);
    st = WdfDmaEnablerCreate(dev, &dc, WDF_NO_OBJECT_ATTRIBUTES, &c->DmaEnabler);
    return st;
}

NTSTATUS EmmcPrepareHardware(_In_ WDFDEVICE Dev, _In_ WDFCMRESLIST Raw, _In_ WDFCMRESLIST Tr)
{
    PEMMC_CONTEXT c = EmmcCtx(Dev);
    ULONG i, n = WdfCmResourceListGetCount(Tr);
    BOOLEAN gotMem = FALSE;
    ULONG nInt = 0;
    NTSTATUS st;

    for (i = 0; i < n; i++) {
        PCM_PARTIAL_RESOURCE_DESCRIPTOR d = WdfCmResourceListGetDescriptor(Tr, i);
        if (!d) return STATUS_DEVICE_CONFIGURATION_ERROR;
        if (d->Type == CmResourceTypeMemory && !gotMem) {
            if (d->u.Memory.Start.QuadPart != (LONGLONG)EMMC_BASE_HC)
                return STATUS_DEVICE_CONFIGURATION_ERROR;
            c->RegLength = d->u.Memory.Length;
            c->Regs = MmMapIoSpaceEx(d->u.Memory.Start, c->RegLength,
                                     PAGE_READWRITE | PAGE_NOCACHE);
            if (!c->Regs) return STATUS_INSUFFICIENT_RESOURCES;
            gotMem = TRUE;
        } else if (d->Type == CmResourceTypeInterrupt) {
            /* _CRS order: [0] hc_irq, [1] pwr_irq. */
            if (nInt == 0 || nInt == 1) {
                WDF_INTERRUPT_CONFIG ic;
                WDFINTERRUPT *slot = (nInt == 0) ? &c->HcInterrupt : &c->PwrInterrupt;
                ULONG want = (nInt == 0) ? EMMC_GSIV_HC : EMMC_GSIV_PWR;
                if (d->u.Interrupt.Vector != want)
                    return STATUS_DEVICE_CONFIGURATION_ERROR;
                if (*slot == NULL) {          /* PrepareHardware can run again on restart */
                    WDF_INTERRUPT_CONFIG_INIT(&ic,
                        nInt == 0 ? EmmcIsr : EmmcPwrIsr,
                        nInt == 0 ? EmmcDpc : NULL);
                    ic.PassiveHandling     = (nInt == 1);   /* pwr_irq calls the power service */
                    ic.InterruptRaw        = WdfCmResourceListGetDescriptor(Raw, i);
                    ic.InterruptTranslated = d;
                    st = WdfInterruptCreate(Dev, &ic, WDF_NO_OBJECT_ATTRIBUTES, slot);
                    if (!NT_SUCCESS(st)) return st;
                }
            }
            nInt++;
        }
    }
    if (!gotMem || nInt != 2) return STATUS_DEVICE_CONFIGURATION_ERROR;

    /* ADMA2 descriptor table: physically contiguous, DMA-mapped, non-paged. */
    st = WdfCommonBufferCreate(c->DmaEnabler, ADMA_TABLE_BYTES,
                               WDF_NO_OBJECT_ATTRIBUTES, &c->AdmaBuffer);
    if (!NT_SUCCESS(st)) return st;
    c->AdmaVa = WdfCommonBufferGetAlignedVirtualAddress(c->AdmaBuffer);
    c->AdmaLa = WdfCommonBufferGetAlignedLogicalAddress(c->AdmaBuffer);
    RtlZeroMemory(c->AdmaVa, ADMA_TABLE_BYTES);

    st = WdfCommonBufferCreate(c->DmaEnabler, DATA_BUFFER_BYTES,
                               WDF_NO_OBJECT_ATTRIBUTES, &c->DataBuffer);
    if (!NT_SUCCESS(st)) return st;
    c->DataVa = WdfCommonBufferGetAlignedVirtualAddress(c->DataBuffer);
    c->DataLa = WdfCommonBufferGetAlignedLogicalAddress(c->DataBuffer);
    RtlZeroMemory(c->DataVa, DATA_BUFFER_BYTES);
    return STATUS_SUCCESS;
}

NTSTATUS EmmcReleaseHardware(_In_ WDFDEVICE Dev, _In_ WDFCMRESLIST Tr)
{
    PEMMC_CONTEXT c = EmmcCtx(Dev);
    UNREFERENCED_PARAMETER(Tr);
    c->Core.Regs = NULL;
    if (c->Regs) { MmUnmapIoSpace(c->Regs, c->RegLength); c->Regs = NULL; }
    return STATUS_SUCCESS;                /* common buffer freed with parent */
}

/* ---- callbacks used by emmc_core ---- */
static VOID EmmcCoreDelayUs(PVOID Ctx, ULONG Us)
{
    UNREFERENCED_PARAMETER(Ctx);
    if (Us < 50) {
        KeStallExecutionProcessor(Us);
    } else {
        LARGE_INTEGER d;
        d.QuadPart = -(LONGLONG)Us * 10;                 /* 100 ns units, relative */
        KeDelayExecutionThread(KernelMode, FALSE, &d);
    }
}

/* Qualcomm SDCC: the card clock is the core clock, set through the power service. */
static int EmmcCoreSetRate(PVOID Ctx, ULONG Hz)
{
    PEMMC_CONTEXT c = (PEMMC_CONTEXT)Ctx;
    return NT_SUCCESS(ResAcquire(c, QRES_SDC1_APPS, Hz)) ? 0 : EMMC_E_IO;   /* re-acquire = change rate */
}

static VOID EmmcCoreAfterReset(PVOID Ctx)
{
    PEMMC_CONTEXT c = (PEMMC_CONTEXT)Ctx;
    Wr32(c, MSM_PWRCTL_MASK, PWRCTL_BUS_OFF | PWRCTL_BUS_ON | PWRCTL_IO_LOW | PWRCTL_IO_HIGH);
    /* TODO(HW): MSM HC mode / vendor-spec init from sdhci-msm.c (offsets unverified). */
}

static NTSTATUS EmmcCoreStatus(int r)
{
    switch (r) {
    case EMMC_OK:        return STATUS_SUCCESS;
    case EMMC_E_TIMEOUT: return STATUS_IO_TIMEOUT;
    case EMMC_E_CRC:     return STATUS_CRC_ERROR;
    case EMMC_E_BADARG:  return STATUS_INVALID_PARAMETER;
    default:             return STATUS_IO_DEVICE_ERROR;
    }
}

NTSTATUS EmmcD0Entry(_In_ WDFDEVICE Dev, _In_ WDF_POWER_DEVICE_STATE Prev)
{
    PEMMC_CONTEXT c = EmmcCtx(Dev);
    NTSTATUS st; int r;
    UNREFERENCED_PARAMETER(Prev);

    st = EmmcOpenPwr(Dev, c);
    if (!NT_SUCCESS(st)) return st;
    /* Order: rails, clocks, then controller reset. The service refuses out-of-range values. */
    st = ResAcquire(c, QRES_SDC1_VQMMC, SDC1_VQMMC_LOW_UV);
    if (NT_SUCCESS(st)) st = ResAcquire(c, QRES_SDC1_VMMC, SDC1_VMMC_UV);
    if (NT_SUCCESS(st)) st = ResAcquire(c, QRES_XO, 0);
    if (NT_SUCCESS(st)) st = ResAcquire(c, QRES_SDC1_AHB, 0);
    if (NT_SUCCESS(st)) st = ResAcquire(c, QRES_SDC1_APPS, 100000000u);     /* lowest OPP */
    if (NT_SUCCESS(st)) st = ResReset(c, QRES_SDC1_BCR);
    if (!NT_SUCCESS(st)) return st;
    /* TODO: GCC_SDCC1_ICE_CORE_CLK only if inline crypto is used. */
    /* Polled bring-up path: reset, power, clock, CMD0/1/2/3/7, EXT_CSD, 8-bit HS (52 MHz).
     * HS200/HS400 need the Qualcomm DLL sequence and are not attempted. */
    RtlZeroMemory(&c->Core, sizeof(c->Core));
    c->Core.Regs       = (volatile u8 *)(c->Regs + EMMC_HOST_REG_OFFSET);
    c->Core.AdmaVa     = c->AdmaVa;
    c->Core.AdmaLa     = (u64)c->AdmaLa.QuadPart;
    c->Core.AdmaBytes  = ADMA_TABLE_BYTES;
    c->Core.DelayUs    = EmmcCoreDelayUs;
    c->Core.SetRate    = EmmcCoreSetRate;
    c->Core.AfterReset = EmmcCoreAfterReset;
    c->Core.Ctx        = c;

    r = emmc_card_init(&c->Core, (u64)c->DataLa.QuadPart, (u8 *)c->DataVa);
    if (r != EMMC_OK) {
        KdPrint(("EMMC: card init failed, core error %d\n", r));
        return EmmcCoreStatus(r);
    }
    c->CardReady = TRUE;
    KdPrint(("EMMC: card ready, %lu sectors (%lu MiB)\n",
             c->Core.SectorCount, c->Core.SectorCount / 2048));

    /* Smoke test: read LBA 0 and check for an MBR/PMBR signature (GPT disks have one too). */
    r = emmc_read(&c->Core, 0, 1, (u64)c->DataLa.QuadPart);
    if (r == EMMC_OK) {
        PUCHAR p = (PUCHAR)c->DataVa;
        UNREFERENCED_PARAMETER(p);                   /* KdPrint compiles away in free builds */
        KdPrint(("EMMC: LBA0 signature bytes %02x %02x (expect 55 aa)\n", p[510], p[511]));
    } else {
        KdPrint(("EMMC: LBA0 read failed, core error %d\n", r));
    }
    return STATUS_SUCCESS;
}

NTSTATUS EmmcD0Exit(_In_ WDFDEVICE Dev, _In_ WDF_POWER_DEVICE_STATE Target)
{
    PEMMC_CONTEXT c = EmmcCtx(Dev);
    UNREFERENCED_PARAMETER(Target);
    c->CardReady = FALSE;
    if (c->Regs && c->Core.Regs) {                           /* D0 entry may have failed early */
        (void)emmc_set_clock(&c->Core, 0);
        Wr32(c, SDHCI_SIGNAL_ENABLE, 0);
        Wr8(c, 0x29, 0);                                   /* SDHCI bus power off */
    }
    if (c->PwrTarget) {
        /* Reverse order of D0 entry. Releasing VQMMC does not switch L14 off: the service holds it. */
        (void)ResRelease(c, QRES_SDC1_APPS);
        (void)ResRelease(c, QRES_SDC1_AHB);
        (void)ResRelease(c, QRES_XO);
        (void)ResRelease(c, QRES_SDC1_VMMC);
        (void)ResRelease(c, QRES_SDC1_VQMMC);
    }
    return STATUS_SUCCESS;
}

VOID EmmcIoctl(_In_ WDFQUEUE Q, _In_ WDFREQUEST Req, _In_ size_t OutLen, _In_ size_t InLen, _In_ ULONG Code)
{
    PEMMC_CONTEXT c = EmmcCtx(WdfIoQueueGetDevice(Q));
    NTSTATUS st; PVOID in = NULL, out = NULL; size_t info = 0;

    if (Code == IOCTL_EMMC_GET_INFO) {
        EMMC_INFO *i;
        if (OutLen < sizeof(*i)) { WdfRequestComplete(Req, STATUS_BUFFER_TOO_SMALL); return; }
        st = WdfRequestRetrieveOutputBuffer(Req, sizeof(*i), &out, NULL);
        if (NT_SUCCESS(st)) {
            i = (EMMC_INFO *)out;
            i->SectorCount = c->Core.SectorCount; i->BusWidth = c->Core.BusWidth; i->Ready = c->CardReady;
            info = sizeof(*i);
        }
        WdfRequestCompleteWithInformation(Req, st, info);
        return;
    }
    if (Code == IOCTL_EMMC_READ_SECTORS) {
        EMMC_READ_REQUEST rq; int r;
        if (InLen < sizeof(rq)) { WdfRequestComplete(Req, STATUS_BUFFER_TOO_SMALL); return; }
        st = WdfRequestRetrieveInputBuffer(Req, sizeof(rq), &in, NULL);
        if (!NT_SUCCESS(st)) { WdfRequestComplete(Req, st); return; }
        rq = *(EMMC_READ_REQUEST *)in;
        if (!c->CardReady) { WdfRequestComplete(Req, STATUS_DEVICE_NOT_READY); return; }
        if (rq.Count == 0 || rq.Count > EMMC_MAX_IOCTL_SECTORS ||
            rq.Lba >= c->Core.SectorCount || rq.Count > c->Core.SectorCount - rq.Lba) {
            WdfRequestComplete(Req, STATUS_INVALID_PARAMETER); return;
        }
        if (OutLen < (size_t)rq.Count * 512) { WdfRequestComplete(Req, STATUS_BUFFER_TOO_SMALL); return; }
        st = WdfRequestRetrieveOutputBuffer(Req, (size_t)rq.Count * 512, &out, NULL);
        if (!NT_SUCCESS(st)) { WdfRequestComplete(Req, st); return; }
        r = emmc_read(&c->Core, rq.Lba, rq.Count, (u64)c->DataLa.QuadPart);
        st = EmmcCoreStatus(r);
        if (NT_SUCCESS(st)) { RtlCopyMemory(out, c->DataVa, (size_t)rq.Count * 512); info = (size_t)rq.Count * 512; }
        WdfRequestCompleteWithInformation(Req, st, info);
        return;
    }
    WdfRequestComplete(Req, STATUS_INVALID_DEVICE_REQUEST);
}

BOOLEAN EmmcIsr(_In_ WDFINTERRUPT Int, _In_ ULONG Msg)
{
    PEMMC_CONTEXT c = EmmcCtx(WdfInterruptGetDevice(Int));
    ULONG s;
    UNREFERENCED_PARAMETER(Msg);
    s = Rd32(c, SDHCI_INT_STATUS);
    if (s == 0 || s == 0xFFFFFFFF) return FALSE;     /* not ours / device gone */
    Wr32(c, SDHCI_INT_STATUS, s);                    /* ack (W1C) */
    c->PendingStatus |= s;                           /* ISR-synchronized with DPC */
    WdfInterruptQueueDpcForIsr(Int);
    return TRUE;
}

VOID EmmcDpc(_In_ WDFINTERRUPT Int, _In_ WDFOBJECT Obj)
{
    PEMMC_CONTEXT c = EmmcCtx(WdfInterruptGetDevice(Int));
    ULONG s;
    UNREFERENCED_PARAMETER(Obj);
    WdfInterruptAcquireLock(Int);
    s = c->PendingStatus; c->PendingStatus = 0;
    WdfInterruptReleaseLock(Int);
    /* TODO: dispatch command-complete / transfer-complete / error bits to request state machine */
    UNREFERENCED_PARAMETER(s);
}

/* pwr_irq: runs at PASSIVE_LEVEL (PassiveHandling) so it may call the power service.
 * Handshake modelled on sdhci_msm_handle_pwr_irq(): read status, clear, perform the
 * bus/IO power change, then acknowledge through PWRCTL_CTL so the controller proceeds.
 * Unverified against hardware. TODO(HW): CORE_IO_PAD_PWR_SWITCH bits in VENDOR_SPEC. */
BOOLEAN EmmcPwrIsr(_In_ WDFINTERRUPT Int, _In_ ULONG Msg)
{
    PEMMC_CONTEXT c = EmmcCtx(WdfInterruptGetDevice(Int));
    ULONG st, ack = 0;
    UNREFERENCED_PARAMETER(Msg);

    st = Rd32(c, MSM_PWRCTL_STATUS);
    if (st == 0 || st == 0xFFFFFFFF) return FALSE;
    Wr32(c, MSM_PWRCTL_CLEAR, st);

    if (st & (PWRCTL_BUS_ON | PWRCTL_BUS_OFF)) {
        /* Card supply (VMMC) is already managed in D0 entry/exit; just acknowledge. */
        ack |= PWRCTL_ACK_BUS_OK;
    }
    if (st & PWRCTL_IO_HIGH) {
        if (NT_SUCCESS(ResAcquire(c, QRES_SDC1_VQMMC, SDC1_VQMMC_HIGH_UV)))
            ack |= PWRCTL_ACK_IO_OK;
    }
    if (st & PWRCTL_IO_LOW) {
        if (NT_SUCCESS(ResAcquire(c, QRES_SDC1_VQMMC, SDC1_VQMMC_LOW_UV)))
            ack |= PWRCTL_ACK_IO_OK;
    }
    Wr32(c, MSM_PWRCTL_CTL, ack);       /* a missing ack bit is how a failed switch is reported */
    return TRUE;
}

/* Called by the tuning code once HS200/HS400 is selected. */
VOID EmmcMsmApplyDdrConfig(_In_ PEMMC_CONTEXT c)
{
    Wr32(c, MSM_DDR_CONFIG, SDC1_DDR_CONFIG);
    /* TODO(HW): DLL bring-up sequence using MSM_DLL_CONFIG (SDC1_DLL_CONFIG) / MSM_DLL_STATUS. */
}
