/* Bring-up interface of the eMMC driver: read-only on purpose (a debug write path could
 * destroy the boot media). Access is restricted to SYSTEM/Administrators by SDDL. */
#ifndef EMMC_IOCTL_H
#define EMMC_IOCTL_H
#include <ntddk.h>
#include <initguid.h>

/* {7C2E4B90-1D3A-4E6F-8A55-0B9E3C7D21F4} */
DEFINE_GUID(GUID_DEVINTERFACE_QRB2210_EMMC,
    0x7c2e4b90, 0x1d3a, 0x4e6f, 0x8a, 0x55, 0x0b, 0x9e, 0x3c, 0x7d, 0x21, 0xf4);

typedef struct _EMMC_INFO { ULONG SectorCount; ULONG BusWidth; ULONG Ready; } EMMC_INFO;
typedef struct _EMMC_READ_REQUEST { ULONG Lba; ULONG Count; } EMMC_READ_REQUEST;  /* Count 1..128 */

#define IOCTL_EMMC_GET_INFO     CTL_CODE(FILE_DEVICE_UNKNOWN, 0x900, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_EMMC_READ_SECTORS CTL_CODE(FILE_DEVICE_UNKNOWN, 0x901, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define EMMC_MAX_IOCTL_SECTORS  128u
#endif
