/*
 * eMMC host core: plain C, no WDF/WDM types, so the same code can sit under a KMDF
 * bring-up shell and later under an SDPORT miniport, and be unit-tested on a host PC
 * (build with -DEMMC_HOST_TEST). Polled operation; interrupts are an optimisation.
 * Standard SDHCI register layout. Qualcomm-specific blocks are NOT touched here.
 */
#ifndef EMMC_CORE_H
#define EMMC_CORE_H

#ifdef EMMC_HOST_TEST
#include <stdint.h>
typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32; typedef uint64_t u64;
#else
#include <ntddk.h>
typedef UCHAR u8; typedef USHORT u16; typedef ULONG u32; typedef ULONG64 u64;
#endif

/* SDHCI registers */
#define SD_BLKSIZE      0x04
#define SD_BLKCOUNT     0x06
#define SD_ARG          0x08
#define SD_XFERMODE     0x0C
#define SD_CMD          0x0E
#define SD_RESP         0x10
#define SD_PRESENT      0x24
#define SD_HOSTCTL      0x28
#define SD_POWER        0x29
#define SD_CLKCTL       0x2C
#define SD_TIMEOUT      0x2E
#define SD_SWRESET      0x2F
#define SD_INTSTAT      0x30
#define SD_INTEN        0x34
#define SD_SIGEN        0x38
#define SD_ADMAADDR     0x58

#define SD_INT_CMDDONE  (1u << 0)
#define SD_INT_XFERDONE (1u << 1)
#define SD_INT_ERROR    (1u << 15)
#define SD_INT_CMD_TMO  (1u << 16)
#define SD_INT_DATA_TMO (1u << 20)
#define SD_INT_ADMA_ERR (1u << 25)
#define SD_INT_ERR_MASK 0x03FF0000u

#define SD_RESET_ALL 0x01
#define SD_RESET_CMD 0x02
#define SD_RESET_DAT 0x04

/* error codes (0 = success) */
enum { EMMC_OK = 0, EMMC_E_TIMEOUT = -1, EMMC_E_CRC = -2, EMMC_E_ADMA = -3,
       EMMC_E_BADARG = -4, EMMC_E_CARD = -5, EMMC_E_IO = -6 };

typedef enum { RSP_NONE, RSP_R1, RSP_R1B, RSP_R2, RSP_R3 } EMMC_RSP;

typedef struct _EMMC_CORE {
    volatile u8 *Regs;          /* SDHCI register window (mapped, uncached) */
    void   *AdmaVa;             /* ADMA2 descriptor table (non-paged, DMA mapped) */
    u64     AdmaLa;             /* its device logical address (< 4 GiB) */
    u32     AdmaBytes;          /* table capacity in bytes */
    u32     BaseClockHz;        /* SDHCI base clock, used only if SetRate == NULL */
    /* Qualcomm SDCC drives the card clock from the core clock: when set, the core asks
     * the platform to set that rate and leaves the SDHCI divider at 0 (like sdhci-msm). */
    int   (*SetRate)(void *Ctx, u32 Hz);
    void  (*DelayUs)(void *Ctx, u32 Us);
    void  (*AfterReset)(void *Ctx);   /* optional: e.g. program Qualcomm PWRCTL mask */
    void   *Ctx;
    /* learned from the card */
    u32     Rca;
    u32     SectorCount;
    u32     BusWidth;
    u32     BootSizeKb;         /* size of EACH boot partition, from EXT_CSD[226] */
    u32     Partition;          /* 0 user, 1/2 boot, 3 RPMB, 4-7 general purpose */
    u32     Resp[4];
} EMMC_CORE;

int  emmc_reset(EMMC_CORE *c, u8 mask);
int  emmc_set_power(EMMC_CORE *c, u32 mv);              /* 1800/3000/3300; MSM raises pwr_irq */
int  emmc_set_clock(EMMC_CORE *c, u32 hz);              /* hz = 0 stops the clock */
void emmc_set_bus(EMMC_CORE *c, u32 width, int highspeed);
int  emmc_cmd(EMMC_CORE *c, u32 idx, u32 arg, EMMC_RSP rsp);
int  emmc_cmd_data(EMMC_CORE *c, u32 idx, u32 arg, EMMC_RSP rsp,
                   u32 blocks, u64 buf_la, int read, int auto_cmd12);
int  emmc_card_init(EMMC_CORE *c, u64 scratch_la, u8 *scratch_va);   /* needs 512 B scratch */
int  emmc_select_partition(EMMC_CORE *c, u32 part, u64 scratch_la, u8 *scratch_va);
int  emmc_read(EMMC_CORE *c, u32 lba, u32 count, u64 buf_la);
int  emmc_write(EMMC_CORE *c, u32 lba, u32 count, u64 buf_la);

/* exposed for tests */
int  emmc_build_adma2(void *table, u32 table_bytes, u64 buf_la, u32 len, u32 *used);

#endif
